package sc.workspace;
 
import djf.ui.AppMessageDialogSingleton;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import javafx.collections.ObservableList;
import javafx.scene.image.Image;
import javafx.stage.DirectoryChooser;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import properties_manager.PropertiesManager;
import sc.SlideshowCreatorApp;
import static sc.SlideshowCreatorProp.APP_PATH_WORK;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_MESSAGE;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_TITLE;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;

/**
 * This class provides responses to all workspace interactions, meaning
 * interactions with the application controls not including the file
 * toolbar.
 * 
 * @author Richard McKenna
 * @version 1.0
 * @editor Tirth Darji
 * @version 1.1
 */
public class SlideshowCreatorController {
    // THE APP PROVIDES ACCESS TO OTHER COMPONENTS AS NEEDED
    SlideshowCreatorApp app;
    
    //To keep the track of added data 
    protected boolean changed = false;
    /**
     * Constructor, note that the app must already be constructed.
     */
    public SlideshowCreatorController(SlideshowCreatorApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
    }
    
    // CONTROLLER METHOD THAT HANDLES ADDING A DIRECTORY OF IMAGES
    //NO DUBLICATES ALLOWED 
    public void handleAddAllImagesInDirectory() {
        try {
            // ASK THE USER TO SELECT A DIRECTORY
            resetChange();
            DirectoryChooser dirChooser = new DirectoryChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            dirChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            File dir = dirChooser.showDialog(app.getGUI().getWindow());
            if (dir != null) {
                File[] files = dir.listFiles();
                for (File f : files) {
                    String fileName = f.getName();
                    if (fileName.toLowerCase().endsWith(".png") ||
                            fileName.toLowerCase().endsWith(".jpg") ||
                            fileName.toLowerCase().endsWith(".gif")) {
                        String path = f.getPath();
                        String caption = "";
                        Image slideShowImage = loadImage(path);
                        int originalWidth = (int)slideShowImage.getWidth();
                        int originalHeight = (int)slideShowImage.getHeight();
                        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                        Slide slide = new Slide(fileName,path,caption,originalWidth, originalHeight);
                        if(!checkContains(slide)){
                            data.addSlide(fileName, path, caption, originalWidth, originalHeight);
                            changed = true;
                        }
                    }
                }
            }
            app.getWorkspaceComponent().activateWorkspace(app.getGUI().getAppPane()); 
        }
        catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }
    
    // THIS HELPER METHOD LOADS AN IMAGE SO WE CAN SEE IT'S SIZE
    private Image loadImage(String imagePath) throws MalformedURLException {
	File file = new File(imagePath);
	URL fileURL = file.toURI().toURL();
	Image image = new Image(fileURL.toExternalForm());
	return image;
    }
    
    //CONTROLLER METHOD TO ADD ONE IMAGE FILE TO CURRENT DATA. 
    //NO DUBLICATES ALLOWED. 
    public void handleOneImageInDirectory() {
        try{ 
            resetChange();
            JFileChooser fc = new JFileChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            FileNameExtensionFilter filter = new FileNameExtensionFilter(
            "JPG, PNG & GIF Images", "jpg", "gif", "png");
            fc.setFileFilter(filter);
            fc.setCurrentDirectory(new File(props.getProperty(APP_PATH_WORK)));
            int returnValue = fc.showOpenDialog(null);
            if (returnValue != JFileChooser.APPROVE_OPTION){return;}
            File dir = fc.getSelectedFile();             
            System.out.println("Get dialog type " + fc.getDialogType());
            if(dir != null){
                
                String fileName = dir.getName();
                String path = dir.getPath();
                String caption = "";
                Image slideShowImage = loadImage(path);
                int originalWidth = (int)slideShowImage.getWidth();
                int originalHeight = (int)slideShowImage.getHeight();
                SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                Slide slide = new Slide(fileName,path,caption,originalWidth, originalHeight);
                if(!checkContains(slide)){
                    data.addSlide(fileName, path, caption, originalWidth, originalHeight); 
                    changed = true;
                }                
            }
            app.getWorkspaceComponent().activateWorkspace(app.getGUI().getAppPane());            
        }
        catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);            
        }   
    }
    
    /*It removes the one slide from the current data file.
    * Being used as the helper for removing only one slide at a time,
    * when remove button pressed.    
    */
    public void handleOneImageRemove(Slide slide) { 
        resetChange();
        if(checkContains(slide)){
            SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
            data.removeSlide(slide);
            changed = true;
        }
    }

    public boolean checkContains(Slide checkFile) {
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        return data.containSlide(checkFile);
    }

    public void resetChange(){
        changed = false;
    }
}