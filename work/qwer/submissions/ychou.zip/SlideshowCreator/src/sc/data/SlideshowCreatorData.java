package sc.data;

import javafx.collections.ObservableList;
import djf.components.AppDataComponent;
import javafx.collections.FXCollections;
import sc.SlideshowCreatorApp;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.HBox;
import sc.workspace.SlideshowCreatorController;

/**
 * This is the data component for SlideshowCreatorApp. It has all the data needed
 * to be set by the user via the User Interface and file I/O can set and get
 * all the data from this object
 * 
 * @author Richard McKenna
 */
public class SlideshowCreatorData implements AppDataComponent {

    // WE'LL NEED ACCESS TO THE APP TO NOTIFY THE GUI WHEN DATA CHANGES
    SlideshowCreatorApp app;
    
    //private boolean duplicate;
    SlideshowCreatorController slideshowCreatorController;
    // NOTE THAT THIS DATA STRUCTURE WILL DIRECTLY STORE THE
    // DATA IN THE ROWS OF THE TABLE VIEW
    ObservableList<Slide> slides;
    
    ObservableList<Slide> duplicateSlides;
    /**
     * This constructor will setup the required data structures for use.
     * 
     * @param initApp The application this data manager belongs to. 
     */
    public SlideshowCreatorData(SlideshowCreatorApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
        
        // MAKE THE SLIDES MODEL
        slides = FXCollections.observableArrayList();
        
        duplicateSlides = FXCollections.observableArrayList();
        //duplicate = false;
        slideshowCreatorController = new SlideshowCreatorController(app);
    }
    
    // ACCESSOR METHOD
    public ObservableList<Slide> getSlides() {
        return slides;
    }
    
    /**
     * Called each time new work is created or loaded, it resets all data
     * and data structures such that they can be used for new values.
     */
    @Override
    public void resetData() {
        slides.clear();
    }
    
    //Remove image
    public void removeSlide(Slide a){
        slides.remove(a);
    }
    
    //check is there any element
    public boolean isEmpty(){
        if (slides.size() == 0)
            return true;
        else
            return false;
    }
    
    // FOR ADDING A SLIDE WHEN THERE ISN'T A CUSTOM SIZE
    public void addSlide(String fileName, String path, String caption, int originalWidth, int originalHeight) {
        
        Slide slideToAdd = new Slide(fileName, path, caption, originalWidth, originalHeight);
        
        boolean duplicate = false;
        
        for (Slide checkSlide : slides){
            if (checkSlide.getFileName().equals(fileName) || checkSlide.getPath().equals(path)){
                duplicateSlides.add(slideToAdd);
                duplicate = true;
            }
        }
        
        
        if (duplicate && slideshowCreatorController.getLastSlide() == true)
            showDuplicatePopupWindow(duplicateSlides);
        else if (duplicate == false)
            slides.add(slideToAdd);
        else if (duplicate == true && slideshowCreatorController.getLastSlide() == false){
            
        }
        
    }

    // FOR ADDING A SLIDE WITH A CUSTOM SIZE
    public void addSlide(String fileName, String path, String caption, int originalWidth, int originalHeight, int currentWidth, int currentHeight) {
        Slide slideToAdd = new Slide(fileName, path, caption, originalWidth, originalHeight);
        slideToAdd.setCurrentWidth(currentWidth);
        slideToAdd.setCurrentHeight(currentHeight);
        
        boolean duplicate = false;
        
        for (Slide checkSlide : slides){
            if (checkSlide.getFileName().equals(fileName) || checkSlide.getPath().equals(path)){
                duplicateSlides.add(slideToAdd);
                duplicate = true;
            }
        }
        
        
        if (duplicate && slideshowCreatorController.getLastSlide() == true)
            showDuplicatePopupWindow(duplicateSlides);
        else if (duplicate == false)
            slides.add(slideToAdd);
        else if (duplicate == true && slideshowCreatorController.getLastSlide() == false){
            
        }
    }
    
    public void showDuplicatePopupWindow(ObservableList<Slide> duplicate){
        
        Button OKButton = new Button("OK");
        VBox pane = new VBox();
        Stage stage = new Stage();
        Scene scene; 
        
        Label messageLabel = new Label();
        Label messageLabel1 = new Label();
        messageLabel1.setText("You already have the following slides in your workspace: ");
        
        String message = "";
        int i = 1;
        for (Slide slide : duplicate){
            message = message + i++ + ". " + slide.getFileName() + "\n";
        }
	messageLabel.setText(message);
        
        OKButton.setOnAction(e -> {
            duplicateSlides.clear();
            stage.close();
        });

        // NOW ORGANIZE OUR BUTTONS
        HBox buttonBox = new HBox();
        buttonBox.getChildren().add(OKButton);
        pane = new VBox();
        pane.setAlignment(Pos.CENTER);
        pane.getChildren().add(messageLabel1);
        pane.getChildren().add(messageLabel);
        pane.getChildren().add(buttonBox);
        
        pane.setPadding(new Insets(10, 20, 20, 20));
        pane.setSpacing(10);

        scene = new Scene(pane);
        
        stage.setTitle("Duplicate");
        stage.setScene(scene);
        stage.show();
    }

    
}