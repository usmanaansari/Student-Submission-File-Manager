package sc.data;

import djf.components.AppDataComponent;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import sc.SlideshowCreatorApp;
import sc.workspace.SlideshowCreatorController;

/**
 * This is the data component for SlideshowCreatorApp. It has all the data needed
 * to be set by the user via the User Interface and file I/O can set and get
 * all the data from this object
 * 
 * @author Richard McKenna
 */
public class SlideshowCreatorData implements AppDataComponent {

    // WE'LL NEED ACCESS TO THE APP TO NOTIFY THE GUI WHEN DATA CHANGES
    SlideshowCreatorApp app;


    // NOTE THAT THIS DATA STRUCTURE WILL DIRECTLY STORE THE
    // DATA IN THE ROWS OF THE TABLE VIEW
    ObservableList<Slide> slides;
    SlideshowCreatorController controller;

    /**
     * This constructor will setup the required data structures for use.
     * 
     * @param initApp The application this data manager belongs to. 
     */
    public SlideshowCreatorData(SlideshowCreatorApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
        controller= (SlideshowCreatorController)app.getDataComponent();
        
        // MAKE THE SLIDES MODEL
        slides = FXCollections.observableArrayList();
    }
    
    // ACCESSOR METHOD

    public ObservableList<Slide> getSlides() {
        return slides;
    }

    /**
     * Called each time new work is created or loaded, it resets all data
     * and data structures such that they can be used for new values.
     */
    @Override
    public void resetData() {

    }

    // FOR ADDING A SLIDE WHEN THERE ISN'T A CUSTOM SIZE
    public void addSlide(String fileName, String path, String caption, int originalWidth, int originalHeight) {
        Slide slideToAdd = new Slide(fileName, path, caption, originalWidth, originalHeight);
//        Image image1= new Image(slideToAdd.getPath());
        slides.add(slideToAdd);
        //slides.add(slideToAdd);
        //app.getGUI().getAppPane().setCenter((Node) slides);
    }

    public void removeSlide(String fileName, String path, String caption, int originalWidth, int originalHeight){
        Slide slideToAdd = new Slide(fileName, path, caption, originalWidth, originalHeight);
        controller = new SlideshowCreatorController(app);
        int size= controller.returnImagineContainer().size();

        for(int i=0;i<slides.size();i++){

            if(slides.get(i).getPath().compareTo(slideToAdd.getPath())==0){
                slides.remove(i);
            }
        }

        for(int j=0;j<size;j++){

            String image= controller.returnImagineContainer().get(j).toString();
            if(image.compareTo(path)==0){

                controller.returnImagineContainer().remove(j);
            }
        }
    }


    // FOR ADDING A SLIDE WITH A CUSTOM SIZE
    public void addSlide(String fileName, String path, String caption, int originalWidth, int originalHeight, int currentWidth, int currentHeight) {
        Slide slideToAdd = new Slide(fileName, path, caption, originalWidth, originalHeight);
        slideToAdd.setCurrentWidth(currentWidth);
        slideToAdd.setCurrentHeight(currentHeight);
        slides.add(slideToAdd);
    }
}