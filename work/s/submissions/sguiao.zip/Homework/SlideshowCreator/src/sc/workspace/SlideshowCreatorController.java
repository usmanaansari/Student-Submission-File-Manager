package sc.workspace;

import djf.ui.AppMessageDialogSingleton;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import javafx.scene.image.Image;
import javafx.stage.DirectoryChooser;
import properties_manager.PropertiesManager;
import sc.SlideshowCreatorApp;
import sc.data.Slide;
import static sc.SlideshowCreatorProp.APP_PATH_WORK;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_MESSAGE;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_TITLE;
import sc.data.SlideshowCreatorData;
import javafx.stage.FileChooser;
import java.util.ArrayList;

/**
 * This class provides responses to all workspace interactions, meaning
 * interactions with the application controls not including the file toolbar.
 *
 * @author Richard McKenna
 * @version 1.0
 */
public class SlideshowCreatorController {

    // THE APP PROVIDES ACCESS TO OTHER COMPONENTS AS NEEDED
    SlideshowCreatorApp app;

    // KEEP TRACK OF ALL PATHS STORED IN SLIDESHOWDATA
    ArrayList<String> dataPaths;

    /**
     * Constructor, note that the app must already be constructed.
     */
    public SlideshowCreatorController(SlideshowCreatorApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
        dataPaths = new ArrayList<>();
    }

    // CONTROLLER METHOD THAT HANDLES ADDING A DIRECTORY OF IMAGES
    public void handleAddAllImagesInDirectory() {
        try {
            // ASK THE USER TO SELECT A DIRECTORY
            DirectoryChooser dirChooser = new DirectoryChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            dirChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            File dir = dirChooser.showDialog(app.getGUI().getWindow());

            if (dir != null) {
                File[] files = dir.listFiles();
                for (File f : files) {
                    String fileName = f.getName();
                    if (fileName.toLowerCase().endsWith(".png")
                            || fileName.toLowerCase().endsWith(".jpg")
                            || fileName.toLowerCase().endsWith(".gif")) {

                        String path = f.getPath();
                        String caption = "";

                        // SHOW ERROR MESSAGE IF IT CONTAINS THE SAME PATH
                        if (dataPaths.contains(path)) {
                            String title = "Duplicate Error";
                            String message = "Error: Slide already exists in data.";
                            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                            dialog.show(title, message);
                            break; // I got too annoyed to figure out a better way. Oh well. 

                        } else {
                            // GET THE IMAGE VIA FILE'S PATH 
                            Image slideShowImage = loadImage(path);
                            int originalWidth = (int) slideShowImage.getWidth();
                            int originalHeight = (int) slideShowImage.getHeight();
                            SlideshowCreatorData data = (SlideshowCreatorData) app.getDataComponent();

                            // ADD THE SLIDE TO THE DATA AND ADD PATH TO ARRAYLIST
                            data.addSlide(fileName, path, caption, originalWidth, originalHeight);
                            dataPaths.add(path);
                        }
                    }
                }
            }
        } catch (MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }

    // THIS HELPER METHOD LOADS AN IMAGE SO WE CAN SEE IT'S SIZE
    private Image loadImage(String imagePath) throws MalformedURLException {
        File file = new File(imagePath);
        URL fileURL = file.toURI().toURL();
        Image image = new Image(fileURL.toExternalForm());
        return image;
    }

    // CONTROLLER METHOD THAT HANDLES ADDING A NEW IMAGE
    public void handleAddingImages() {
        try {
            // OPEN A FILECHOOSER TO CHOOSE A FILE
            FileChooser fileChooser = new FileChooser();

            // SET UP THE PROPERTIES MANAGER
            PropertiesManager props = PropertiesManager.getPropertiesManager();

            // SET THE FILECHOOSER TO A SET DIRECTORY 
            fileChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));

            // STORE SELECTED FILE IN FILE OBJECT 
            File selectedFile = fileChooser.showOpenDialog(app.getGUI().getWindow());

            // IF THE SELECTED FILE OBJECT IS NOT NULL ADD TO WORKSHPACE 
            if (selectedFile != null) {
                String fileName = selectedFile.getName();

                if (fileName.toLowerCase().endsWith(".png")
                        || fileName.toLowerCase().endsWith(".jpg")
                        || fileName.toLowerCase().endsWith(".gif")) {

                    // GET THE SELECTEDFILE'S PATH 
                    String path = selectedFile.getPath();
                    String caption = "";

                    // CHECK FOR DUPLICATES 
                    SlideshowCreatorData data = (SlideshowCreatorData) app.getDataComponent();

                    // SHOW ERROR MESSAGE IF IT CONTAINS THE SAME PATH
                    if (dataPaths.contains(path)) {
                        String title = "Duplicate Error";
                        String message = "Error: Slide already exists in data.";
                        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                        dialog.show(title, message);
                    } else {
                        // GET THE IMAGE VIA FILE'S PATH 
                        Image slideShowImage = loadImage(path);
                        int originalWidth = (int) slideShowImage.getWidth();
                        int originalHeight = (int) slideShowImage.getHeight();

                        // ADD THE SLIDE TO THE DATA AND PATH TO ARRAYLIST
                        data.addSlide(fileName, path, caption, originalWidth, originalHeight);
                        dataPaths.add(path);

                        // SELECT ADDED IMAGE 
                        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
                        workspace.slidesTableView.getSelectionModel().select(data.getSlides().size() - 1);
                        handleSelectedItem();
                                                workspace.updateButton.setDisable(true); 

                    }
                }
            }
        } catch (MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }

    // DISPLAYS INFORMATION ABOUT THE SELECTED SLIDE IN THE TABLEVIEW
    public void handleSelectedItem() {
        // ACCESS THE WORKSPACE 
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();

        // ENABLE SLIDERS CAPTION AND REMOVE BUTTON
        workspace.currentHeightSlider.setDisable(false);
        workspace.currentWidthSlider.setDisable(false);
        workspace.captionTextField.setDisable(false);
        workspace.removeImageButton.setDisable(false);

        // GET THE SELECTED SLIDE 
        Slide slide = workspace.slidesTableView.getSelectionModel().getSelectedItem();

        // OBTAIN THE SLIDE'S PROPERTIES 
        try {
            String fileName = slide.getFileName();
            String path = slide.getPath();
            String caption = slide.getCaption();
            int initWidth = slide.getOriginalWidth();
            int initHeight = slide.getOriginalHeight();
            int currWidth = slide.getCurrentWidth();
            int currHeight = slide.getCurrentHeight();

            // RESET THE RIGHT SIDE OF THE WORKSPACE
            workspace.fileNameTextField.setText(fileName);
            workspace.pathTextField.setText(path);
            workspace.captionTextField.setText(caption);
            workspace.originalWidthTextField.setText(Integer.toString(initWidth));
            workspace.originalHeightTextField.setText(Integer.toString(initHeight));
            workspace.currentWidthSlider.setValue(currWidth);
            workspace.currentHeightSlider.setValue(currHeight);

        } catch (NullPointerException e) {

        }
    }

    // UPDATES THE SLIDES INFORMATION 
    public void handleUpdate() {
        // GET THE VALUES FROM THE WORKSPACE 
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
        String caption = workspace.captionTextField.getText();
        int sliderWidth = (int) workspace.currentWidthSlider.getValue();
        int sliderHeight = (int) workspace.currentHeightSlider.getValue();

        // UPDATE THE SELECTED SLIDE 
        Slide selectedSlide = workspace.slidesTableView.getSelectionModel().getSelectedItem();
        selectedSlide.setCaption(caption);
        selectedSlide.setCurrentWidth(sliderWidth);
        selectedSlide.setCurrentHeight(sliderHeight);

        // UPDATE THE TABLEVIEW
        workspace.slidesTableView.refresh();
    }

    public void handleRemove() {
        // REMOVE SELECTED SLIDE
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
        Slide selectedSlide = workspace.slidesTableView.getSelectionModel().getSelectedItem();
        workspace.slidesTableView.getItems().remove(selectedSlide);

        // REMOVE SLIDE FROM DATA 
        SlideshowCreatorData data = (SlideshowCreatorData) app.getDataComponent();
        data.removeSlide(selectedSlide);

        // REMOVE NAME FROM DATAPATH 
        dataPaths.remove(selectedSlide.getPath());

        // DESELECT FROM TABLEVIEW
        workspace.slidesTableView.getSelectionModel().clearSelection();

        // CLEAR ALL FIELDS FROM RIGHT TOOLBAR
        workspace.fileNameTextField.clear();
        workspace.captionTextField.clear();
        workspace.pathTextField.clear();
        workspace.originalWidthTextField.clear();
        workspace.originalHeightTextField.clear();
        workspace.currentWidthSlider.setValue(0);
        workspace.currentHeightSlider.setValue(0);

        // DISABLE THE RIGHT TOOLBAR IF NO SLIDES EXIST
        if (dataPaths.size() == 0) {
            workspace.removeImageButton.setDisable(true);
            workspace.captionTextField.setDisable(true);
            workspace.currentWidthSlider.setDisable(true);
            workspace.currentHeightSlider.setDisable(true);
            workspace.updateButton.setDisable(true);
        }
    }

    public void handleCaption() 
    {
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
        workspace.updateButton.setDisable(false);
    }
}
