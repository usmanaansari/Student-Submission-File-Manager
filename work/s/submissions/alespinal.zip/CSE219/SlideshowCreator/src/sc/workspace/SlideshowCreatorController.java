package sc.workspace;

import djf.ui.AppMessageDialogSingleton;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import properties_manager.PropertiesManager;
import sc.SlideshowCreatorApp;
import static sc.SlideshowCreatorProp.APP_PATH_WORK;
import static sc.SlideshowCreatorProp.DUPLICATE_IMAGES_MESSAGE;
import static sc.SlideshowCreatorProp.DUPLICATE_IMAGES_TITLE;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_MESSAGE;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_TITLE;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;

/**
 * This class provides responses to all workspace interactions, meaning
 * interactions with the application controls not including the file
 * toolbar.
 * 
 * @author Richard McKenna
 * @version 1.0
 */
public class SlideshowCreatorController {
    // THE APP PROVIDES ACCESS TO OTHER COMPONENTS AS NEEDED
    SlideshowCreatorApp app;

    /**
     * Constructor, note that the app must already be constructed.
     * @param initApp
     */
    public SlideshowCreatorController(SlideshowCreatorApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
    }
    
    // CONTROLLER METHOD THAT HANDLES ADDING A DIRECTORY OF IMAGES
    public void handleAddAllImagesInDirectory() {
        try {
            // ASK THE USER TO SELECT A DIRECTORY
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            
            DirectoryChooser dirChooser = new DirectoryChooser();            
            dirChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            
            File dir = dirChooser.showDialog(app.getGUI().getWindow());
            
            ArrayList<String> duplicateImages = new ArrayList<>();
            boolean hasDuplicates = false;
            if (dir != null) {
                File[] files = dir.listFiles();
                for (File f : files) {
                    String fileName = f.getName();
                    String path = f.getPath();
                    if (!isDuplicateImage(path, fileName) & 
                            (fileName.toLowerCase().endsWith(".png") ||
                            fileName.toLowerCase().endsWith(".jpg") ||
                            fileName.toLowerCase().endsWith(".gif"))) {                        
                        String caption = "";
                        Image slideShowImage = loadImage(path);
                        int originalWidth = (int)slideShowImage.getWidth();
                        int originalHeight = (int)slideShowImage.getHeight();
                        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                        data.addSlide(fileName, path, caption, originalWidth, originalHeight);
                    } else{
                        duplicateImages.add(fileName);
                        hasDuplicates = true;
                    }
                }
                
                if(hasDuplicates){
                    duplicateImagesDialog(duplicateImages);
                }
            }
            markAsEdited();
        }
        catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }
    
    /**
     * handleAddImageFile - 
     * Controller method that handles adding a single image.
     */
    public void handleAddSlide(){        
        try {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            
            FileChooser fc = new FileChooser();            
            fc.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            
            // With this filter there is no need fot the second part of the conditionals
            fc.getExtensionFilters().add(new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"));
            File selectedImage = fc.showOpenDialog(app.getGUI().getWindow());
            
            ArrayList<String> duplicateImages = new ArrayList<>();
            if(selectedImage != null){     
                String fileName = selectedImage.getName();
                String path = selectedImage.getPath();
                // Checks if not a duplicate image and if it ends with an 
                // acceptable file extension.
                if (!isDuplicateImage(path, fileName)) {                   
                   String caption = "";
                   Image slideShowImage = loadImage(path);
                   int originalWidth = (int)slideShowImage.getWidth();
                   int originalHeight = (int)slideShowImage.getHeight();
                   SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                   data.addSlide(fileName, path, caption, originalWidth, originalHeight);
               }     
                else{
                    duplicateImages.add(fileName);
                    duplicateImagesDialog(duplicateImages);                    
                }
                markAsEdited();
            }
        }catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }
    
    /**
     * duplicateImagesDialog - 
     * @param duplicateFileNames 
     * Prompts the user with a list of duplicate images if any have been chosen.
     */
    private void duplicateImagesDialog(ArrayList<String> duplicateFileNames){
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        
        String title = props.getProperty(DUPLICATE_IMAGES_TITLE);
        String message = props.getProperty(DUPLICATE_IMAGES_MESSAGE) + "\n\n";
        
        for(String str : duplicateFileNames){
            message += str + "\n";
        }
    
        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
        dialog.show(title, message);
    }
    
   /**
    * isDuplicateImage - 
    * @param path
    * @param fileName
    * @return true if image already exist in table.
    */
    private boolean isDuplicateImage(String path, String fileName){        
        // Access the observable list
        // Check if that name exist.
        // Return true if it does
        // Return false otherwise.
        
        SlideshowCreatorData dataManager = (SlideshowCreatorData) app.getDataComponent();
        ObservableList<Slide> slides = dataManager.getSlides();
        
        for(Slide s : slides){
            if(s.getPath().equals(path) && s.getFileName().equals(fileName)){
                return true;
            }
        }
        return false;
    }
    
    // THIS HELPER METHOD LOADS AN IMAGE SO WE CAN SEE IT'S SIZE
    private Image loadImage(String imagePath) throws MalformedURLException {
	File file = new File(imagePath);
	URL fileURL = file.toURI().toURL();
	Image image = new Image(fileURL.toExternalForm());
	return image;
    }
    
    /**
     * handleLoadSlide - 
     * Loads a slide chosen from the table to the editpane.
     */
    public void handleLoadSlide(){
        
        // Grab the Slideshow table
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
        TableView scTable = workspace.slidesTableView;
        
        // Which object was selected?
        Object selectedItem = scTable.getSelectionModel().getSelectedItem();
        
        if(selectedItem != null){
            // Which slide was selected?
            Slide slide = (Slide) selectedItem;
            // Store the values you wish to display
            String fileName = slide.getFileName();
            String path = slide.getPath();
            String caption = slide.getCaption();
            int originalWidth = slide.getOriginalHeight();
            int originalHeight = slide.getOriginalHeight();
            int currentWidth = slide.getCurrentWidth();
            int currentHeight = slide.getCurrentHeight();
            //Enable the caption textfield and the sliders.
            workspace.captionTextField.setDisable(false);
            workspace.currentWidthSlider.setDisable(false);
            workspace.currentHeightSlider.setDisable(false);
            // Set the editpane controls to the current slides attributes.
            workspace.fileNameTextField.setText(fileName);
            workspace.pathTextField.setText(path);
            workspace.captionTextField.setText(caption);
            workspace.originalWidthTextField.setText(String.valueOf(originalWidth));
            workspace.originalHeightTextField.setText(String.valueOf(originalHeight));
            workspace.currentWidthSlider.setValue(currentWidth);
            workspace.currentHeightSlider.setValue(currentHeight);
            // Enable the remove button
            workspace.removeImageButton.setDisable(false);
            
            // Incase the update button was enabled and the user switched to a
            // diffrent slide without updating, this will ensure that it is 
            // disabled.
            workspace.updateButton.setDisable(true);
        }
    }
    
    /**
     * handleUpdateSlide -
     * Updates the selected slide to the new values chosen by the user.
     */
    public void handleUpdateSlide(){
        // Gran the workspace to get access to the desired values.
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
        String caption = workspace.captionTextField.getText();
        int currentWidth = (int) workspace.currentWidthSlider.getValue();
        int currentHeight = (int) workspace.currentHeightSlider.getValue();  
        
        // Which object was selected?
        TableView scTable = workspace.slidesTableView;
        Object selectedItem = scTable.getSelectionModel().getSelectedItem();        
        
        // Which slide was selected?
        Slide slide = (Slide) selectedItem;
        slide.setCaption(caption);
        slide.setCurrentWidth(currentWidth);
        slide.setCurrentHeight(currentHeight);      
        
        // Enable the remove button
        workspace.removeImageButton.setDisable(true);
        workspace.updateButton.requestFocus();
        markAsEdited();
    }

    /**
     * handleRemoveSlide - 
     * Removes a slide from the table.
     */
    public void handleRemoveSlide() {
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
        TableView scTable = workspace.slidesTableView;
        Object selectedItem = scTable.getSelectionModel().getSelectedItem();        
        
        SlideshowCreatorData dataManager = (SlideshowCreatorData)app.getDataComponent();
        Slide slide = (Slide) selectedItem;
        String fileName = slide.getFileName();
        String path = slide.getPath();
        dataManager.removeSlide(fileName, path);            
               
        markAsEdited();
    }
    
    /**
     * markAsEdited - 
     * Enables the save button after a change has been made to a slide.
     */
    private void markAsEdited(){
        app.getGUI().markAsEdited();
    }


    
}