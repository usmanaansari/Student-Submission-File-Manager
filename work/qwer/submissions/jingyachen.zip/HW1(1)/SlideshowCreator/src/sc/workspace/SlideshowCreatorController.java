package sc.workspace;

import djf.ui.AppMessageDialogSingleton;
import djf.ui.AppYesNoCancelDialogSingleton;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import properties_manager.PropertiesManager;
import sc.SlideshowCreatorApp;
import static sc.SlideshowCreatorProp.APP_PATH_WORK;
import static sc.SlideshowCreatorProp.DUPLICATE_IMAGES_WARNING_MESSAGE;
import static sc.SlideshowCreatorProp.DUPLICATE_IMAGES_WARNING_TITLE;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_MESSAGE;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_TITLE;
import static sc.SlideshowCreatorProp.NO_DUPLICATE_IMAGES_MESSAGE;
import static sc.SlideshowCreatorProp.NO_DUPLICATE_IMAGES_TITLE;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;

/**
 * This class provides responses to all workspace interactions, meaning
 * interactions with the application controls not including the file
 * toolbar.
 * 
 * @author Richard McKenna
 * @version 1.0
 */
public class SlideshowCreatorController {
    // THE APP PROVIDES ACCESS TO OTHER COMPONENTS AS NEEDED
    SlideshowCreatorApp app;
    public ObservableList<Slide> Slide;
  
    /**
     * Constructor, note that the app must already be constructed.
     */
    public SlideshowCreatorController(SlideshowCreatorApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
    }
    
    // CONTROLLER METHOD THAT HANDLES ADDING A DIRECTORY OF IMAGES
    
     public void handleAddAllImagesInDirectory() {
        
            // ASK THE USER TO SELECT A DIRECTORY
            
            DirectoryChooser dirChooser = new DirectoryChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            dirChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            File dir = dirChooser.showDialog(app.getGUI().getWindow());
            if (dir != null) {
                File[] files = dir.listFiles();
                SlideshowCreatorWorkspace workspace=(SlideshowCreatorWorkspace)app.getWorkspaceComponent();
                SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                ObservableList<Slide> exsistingItem = data.getSlides();
                boolean check=false;
                int count=0;
                
                for (File f : files) {
                    
                    String fileName = f.getName();
                     String path = f.getPath();
                    if (fileName.toLowerCase().endsWith(".png") ||
                            fileName.toLowerCase().endsWith(".jpg") ||
                            fileName.toLowerCase().endsWith(".gif")) {
                       for(Slide sl:exsistingItem) {
                           if(sl.getFileName().equals(fileName)||sl.getPathProperty().equals(path)){
                           
                           
                               AppYesNoCancelDialogSingleton dialog=AppYesNoCancelDialogSingleton.getSingleton();
                                     String title = props.getProperty(DUPLICATE_IMAGES_WARNING_TITLE);
                                     String message = props.getProperty(DUPLICATE_IMAGES_WARNING_MESSAGE);
                                     dialog.show(title, message); 
                                 String result=dialog.getSelection();
                                 if(result.equals(AppYesNoCancelDialogSingleton.YES)){
                                   count=-1;
                                 }
                                 else
                                     count++;    
                           }       
                       }
                    }
                }           
                         
              try { 
                  if(count==-1||count==0){
                
                for (File f : files) {
                    
                    String fileName = f.getName();
                    if (fileName.toLowerCase().endsWith(".png") ||
                            fileName.toLowerCase().endsWith(".jpg") ||
                            fileName.toLowerCase().endsWith(".gif")) {
                        
                        String path = f.getPath();
                        String caption = "";
                        Image slideShowImage = loadImage(path);
                        int originalWidth = (int)slideShowImage.getWidth();
                        int originalHeight = (int)slideShowImage.getHeight();
                        
                        
                        for(Slide sl:exsistingItem){
                            if(sl.getFileName().equals(fileName)){
                            check=true;
                            
                            }
                   
                        }
                        
                        if(check!=true){
                        app.getGUI().updateToolbarControls(false);
                        data.addSlide(fileName, path, caption, originalWidth, originalHeight);
                        }
                         
                    }
               
                
                }
                  }
            }
            
        catch(MalformedURLException murle) {
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }       
     }
                        
    
    
    
                // CONREOLLOR METHOD FOR ADDING A SINGLE IMAGE
    
    
    public Slide handleAddSingleImageDirectory(){
      /*
       @author Jingyao chen 
       */
        Slide selected=null;
   try{  
           FileChooser fChooser=new FileChooser();
           File sf=fChooser.showOpenDialog(app.getGUI().getWindow());
            if ( sf!= null) {
                      String fileName = sf.getName();
                       if (fileName.toLowerCase().endsWith(".png") ||
                           fileName.toLowerCase().endsWith(".jpg") ||
                           fileName.toLowerCase().endsWith(".gif")) {
                        String path = sf.getPath();
                        String caption = "";
                        Image slideShowImage = loadImage(path);
                        int originalWidth = (int)slideShowImage.getWidth();
                        int originalHeight = (int)slideShowImage.getHeight();
                           SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                           ObservableList<Slide> tableData=data.getSlides();
                            boolean ifExisted=true;                      
                           for(Slide slide:tableData){
                            
                                 if(slide.getFileName().equalsIgnoreCase(fileName)){
                                  ifExisted=false;
                                 }   
                           }
                               if(ifExisted!=false){
                                   
                                   data.addSlide(fileName, path, caption, originalWidth, originalHeight);
                                   app.getGUI().updateToolbarControls(false);
                                   for(Slide slide:tableData){
                                   
                                     if  (slide.getFileName().equals(fileName)){
                                     
                                         selected=slide;
                                     
                                     }
                                   }
                               }
                               else{
                                    PropertiesManager props = PropertiesManager.getPropertiesManager();
                                    String title = props.getProperty(NO_DUPLICATE_IMAGES_TITLE);
                                    String message = props.getProperty(NO_DUPLICATE_IMAGES_MESSAGE);
                                    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                                    dialog.show(title, message);   
                                   
                               }
                           }
                           
                       } 
            }
                
   
        catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
         return selected;
    }
    
    
    // THIS HELPER METHOD LOADS AN IMAGE SO WE CAN SEE IT'S SIZE
    private Image loadImage(String imagePath) throws MalformedURLException {
	File file = new File(imagePath);
	URL fileURL = file.toURI().toURL();
	Image image = new Image(fileURL.toExternalForm());
	return image;
    }
    public void handleRemoveSlide(){
        
            SlideshowCreatorWorkspace workspace=(SlideshowCreatorWorkspace)app.getWorkspaceComponent();
            SlideshowCreatorData data=(SlideshowCreatorData)app.getDataComponent();
              Object selectedItem= workspace.slidesTableView.getSelectionModel().getSelectedItem();
                Slide sl=(Slide)selectedItem;
                
              String filename=sl.getFileName();
              String path=sl.getPath();
              String caption=sl.getCaption();
              int originalWidth=(int)sl.getOriginalWidth();
              int originalHeight=(int)sl.getOriginalHeight();
        
              data.removeSlide(filename,path,caption,originalWidth,originalHeight);
              app.getGUI().updateToolbarControls(false);
    }
    
    
    public void handleUpdate(){
      
            SlideshowCreatorWorkspace workspace=(SlideshowCreatorWorkspace)app.getWorkspaceComponent();
            SlideshowCreatorData data=(SlideshowCreatorData)app.getDataComponent();
              Object selectedItem= workspace.slidesTableView.getSelectionModel().getSelectedItem();
                Slide sl=(Slide)selectedItem;
                
              String filename=sl.getFileName();
              String path=sl.getPath();
              String caption=sl.getCaption();
              int originalWidth=(int)sl.getOriginalWidth();
              int originalHeight=(int)sl.getOriginalHeight();
              
              String newCaption=workspace.captionTextField.getText();
              int newWidth=(int)workspace.currentWidthSlider.getValue();
              int newHeight=(int)workspace.currentHeightSlider.getValue();
              
              data.updateSlide(filename,path,caption,originalWidth,originalHeight,newCaption,newWidth,newHeight);
              app.getGUI().updateToolbarControls(false);
               
    }
    
    
}