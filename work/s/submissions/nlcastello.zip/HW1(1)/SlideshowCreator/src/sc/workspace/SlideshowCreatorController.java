package sc.workspace;

import djf.ui.AppMessageDialogSingleton;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import properties_manager.PropertiesManager;
import sc.SlideshowCreatorApp;
import static sc.SlideshowCreatorProp.APP_PATH_WORK;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_MESSAGE;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_TITLE;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;

/**
 * This class provides responses to all workspace interactions, meaning
 * interactions with the application controls not including the file
 * toolbar.
 * 
 * @author Richard McKenna
 * @version 1.0
 */
public class SlideshowCreatorController {
    // THE APP PROVIDES ACCESS TO OTHER COMPONENTS AS NEEDED
    SlideshowCreatorApp app;

    /**
     * Constructor, note that the app must already be constructed.
     */
    public SlideshowCreatorController(SlideshowCreatorApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
    }
    
    // CONTROLLER METHOD THAT HANDLES ADDING A DIRECTORY OF IMAGES
    public void handleAddAllImagesInDirectory() {
        boolean isDuplicate = false;
        try {
            // ASK THE USER TO SELECT A DIRECTORY
            DirectoryChooser dirChooser = new DirectoryChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            dirChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            File dir = dirChooser.showDialog(app.getGUI().getWindow());
            if (dir != null) {
                File[] files = dir.listFiles();
				StringBuilder errorMessage = new StringBuilder();
                for (File f : files) {
                    isDuplicate = false;
                    String fileName = f.getName();
                    if (fileName.toLowerCase().endsWith(".png") ||
                            fileName.toLowerCase().endsWith(".jpg") ||
                            fileName.toLowerCase().endsWith(".gif")) {
                        String path = f.getPath();
                        String caption = "";
                        Image slideShowImage = loadImage(path);
                        int originalWidth = (int)slideShowImage.getWidth();
                        int originalHeight = (int)slideShowImage.getHeight();
                        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                        Slide newestSlide = new Slide(fileName, path, caption, originalWidth, originalHeight);
                        
                        for(int i = 0; i < data.getSlides().size(); i++){
                                if(newestSlide.getFileName().equals(data.getSlides().get(i).getFileName()) 
                                        && newestSlide.getPath().equals(data.getSlides().get(i).getPath())){
                                    isDuplicate = true;
                                        errorMessage.append("\n" + newestSlide.getFileName());
                                }
                            }
                        if(isDuplicate == false){
                            data.addSlide(newestSlide);
                            addedFileNames.add(fileName);
                        }
                    }
                }
				
				if(errorMessage.length() > 0){
					Alert alert = new Alert(AlertType.ERROR);
					alert.setTitle("Error Dialog");
					alert.setHeaderText("Error");
					alert.setContentText("The following files were already added!\n" + errorMessage.toString()); 
					alert.showAndWait();
				}
            }
        }
        catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }
    
    ArrayList<String> addedFileNames = new ArrayList();
    
    public void handleAddSingleImage(){
        boolean isDuplicate = false;
        try{
            FileChooser imgChooser = new FileChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            imgChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            File img = imgChooser.showOpenDialog(app.getGUI().getWindow());
            String fileName = img.getName();
            if (img != null) {
                    if (fileName.toLowerCase().endsWith(".png") ||
                                fileName.toLowerCase().endsWith(".jpg") ||
                                fileName.toLowerCase().endsWith(".gif")) {
                            String path = img.getPath();
                            String caption = "";
                            Image slideShowImage = loadImage(path);
                            int originalWidth = (int)slideShowImage.getWidth();
                            int originalHeight = (int)slideShowImage.getHeight();
                            SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                            Slide newestSlide = new Slide(fileName, path, caption, originalWidth, originalHeight);
                            for(int i = 0; i < data.getSlides().size(); i++){
                                if(newestSlide.getFileName().equals(data.getSlides().get(i).getFileName()) 
                                        && newestSlide.getPath().equals(data.getSlides().get(i).getPath())){
                                    isDuplicate = true;
                                    Alert alert = new Alert(AlertType.ERROR);
                                    alert.setTitle("Error Dialog");
                                    alert.setHeaderText("Error");
                                    alert.setContentText("This file was already added!");
                                    alert.showAndWait();
                                }
                            }
                            if(isDuplicate == false){
                                data.addSlide(newestSlide);
                                addedFileNames.add(newestSlide.getFileName());
                            }
                            
                        }
                    }
        }
        catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }
    
    public ArrayList getFileNames(){
        return addedFileNames;
    }
    
    public void handleRemoveImage(TableView<Slide> table, Slide selectedSlide){
        //table.remove(table.getSelectionModel().getSelectedItem()); //fix
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        data.deleteSlide(selectedSlide);
       
        
        addedFileNames.remove(selectedSlide.getFileName());
        
        
    }
    
    
    
    
    // THIS HELPER METHOD LOADS AN IMAGE SO WE CAN SEE IT'S SIZE
    private Image loadImage(String imagePath) throws MalformedURLException {
	File file = new File(imagePath);
	URL fileURL = file.toURI().toURL();
	Image image = new Image(fileURL.toExternalForm());
	return image;
    }
}