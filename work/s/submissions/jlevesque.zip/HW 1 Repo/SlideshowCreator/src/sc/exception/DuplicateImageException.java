
package sc.exception;



/**
 * Provides a custom exception to be thrown when the user attempts to add a duplicate image.
 * @author J. Levesque
 * @version 1.0
 */
public class DuplicateImageException extends Exception {

   public DuplicateImageException(String message){
       super(message);
   }
    
}
