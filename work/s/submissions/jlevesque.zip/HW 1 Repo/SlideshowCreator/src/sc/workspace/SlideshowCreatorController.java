package sc.workspace;

import djf.ui.AppMessageDialogSingleton;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import javafx.scene.image.Image;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import properties_manager.PropertiesManager;
import sc.SlideshowCreatorApp;
import static sc.SlideshowCreatorProp.APP_PATH_WORK;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_MESSAGE;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_TITLE;
import static sc.SlideshowCreatorProp.DUPLICATE_IMAGE_TITLE;
import static sc.SlideshowCreatorProp.DUPLICATE_IMAGE_MESSAGE;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;
import sc.exception.DuplicateImageException;

import djf.controller.AppFileController;

/**
 * This class provides responses to all workspace interactions, meaning
 * interactions with the application controls not including the file
 * toolbar.
 * 
 * @author Richard McKenna
 * @author J. Levesque
 * @version 1.0
 */
public class SlideshowCreatorController {
    // THE APP PROVIDES ACCESS TO OTHER COMPONENTS AS NEEDED
    SlideshowCreatorApp app;

    /**
     * Constructor, note that the app must already be constructed.
     */
    public SlideshowCreatorController(SlideshowCreatorApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
    }
    
    // CONTROLLER METHOD THAT HANDLES ADDING A DIRECTORY OF IMAGES
    public void handleAddAllImagesInDirectory() {
        try {
            // ASK THE USER TO SELECT A DIRECTORY
            DirectoryChooser dirChooser = new DirectoryChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            dirChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            File dir = dirChooser.showDialog(app.getGUI().getWindow());
            if (dir != null) {
                File[] files = dir.listFiles();
                for (File f : files) {
                    String fileName = f.getName();
                    if (fileName.toLowerCase().endsWith(".png") ||
                            fileName.toLowerCase().endsWith(".jpg") ||
                            fileName.toLowerCase().endsWith(".gif")) {
                        String path = f.getPath();
                        String caption = "";
                        Image slideShowImage = loadImage(path);
                        int originalWidth = (int)slideShowImage.getWidth();
                        int originalHeight = (int)slideShowImage.getHeight();
                        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                        if(!data.hasSlide(fileName, path)){
                            data.addSlide(fileName, path, caption, originalWidth, originalHeight);
                        }
                    }
                }
                handleDeselectAllImages();
                enableSave();
            }
        }
        catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }
    
    // Controller method that handles adding a single image
    public void handleAddImage() {
        try{
            // Ask the user to select a file
            FileChooser fileChooser = new FileChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            fileChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            File file = fileChooser.showOpenDialog(app.getGUI().getWindow());
            if(file != null){
                String fileName = file.getName();
                 if (fileName.toLowerCase().endsWith(".png") ||
                            fileName.toLowerCase().endsWith(".jpg") ||
                            fileName.toLowerCase().endsWith(".gif")) {
                        String path = file.getPath();
                        String caption = "";
                        Image slideShowImage = loadImage(path);
                        int originalWidth = (int)slideShowImage.getWidth();
                        int originalHeight = (int)slideShowImage.getHeight();
                        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                        if(data.hasSlide(fileName, path)){
                            throw new DuplicateImageException(PropertiesManager.getPropertiesManager().getProperty(DUPLICATE_IMAGE_TITLE));
                        }
                        data.addSlide(fileName, path, caption, originalWidth, originalHeight);
                       SlideshowCreatorWorkspace SSCWorkspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
                       SSCWorkspace.slidesTableView.getSelectionModel().clearSelection();
                       SSCWorkspace.slidesTableView.getSelectionModel().selectLast();
                       handleSelectImage();
                       enableSave();
                    }
            }
        }
        catch(MalformedURLException murle){
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
        catch(DuplicateImageException die){
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(DUPLICATE_IMAGE_TITLE);
            String message = props.getProperty(DUPLICATE_IMAGE_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }
    
    // Controller method that handles removing an image
    public void handleRemoveImage(){
        SlideshowCreatorWorkspace SSCWorkspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        if(!SSCWorkspace.slidesTableView.getSelectionModel().isEmpty()){ // if a slide is selected
            Slide selectedSlide = (Slide)SSCWorkspace.slidesTableView.getSelectionModel().getSelectedItem();
            handleDeselectAllImages();
            ((SlideshowCreatorData)app.getDataComponent()).getSlides().remove(selectedSlide);
        }
        enableSave();
    }
    
    // Controller method that handles selecting an image
    public void handleSelectImage(){
        SlideshowCreatorWorkspace SSCWorkspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        if(!SSCWorkspace.slidesTableView.getSelectionModel().isEmpty()){ // if a slide is selected
            Slide selectedSlide = (Slide)SSCWorkspace.slidesTableView.getSelectionModel().getSelectedItem();
            SSCWorkspace.fileNameTextField.setText(selectedSlide.getFileName());
            SSCWorkspace.pathTextField.setText(selectedSlide.getPath());
            SSCWorkspace.captionTextField.setText(selectedSlide.getCaption());
            SSCWorkspace.originalWidthTextField.setText(selectedSlide.getOriginalWidth().toString());
            SSCWorkspace.originalHeightTextField.setText(selectedSlide.getOriginalHeight().toString());
            SSCWorkspace.currentHeightSlider.setValue(selectedSlide.getCurrentHeight());
            SSCWorkspace.currentWidthSlider.setValue(selectedSlide.getCurrentWidth());
            SSCWorkspace.toggleRemoveImageButton(); // enable the remove image button
            SSCWorkspace.toggleUpdateButton(false); // disable the update button
            SSCWorkspace.toggleUserInputFields(); // enable user input into the caption and current width/height fields
        }
    }
    
    // Controller method that handles deselecting all images
    public void handleDeselectAllImages(){
        SlideshowCreatorWorkspace SSCWorkspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        SSCWorkspace.slidesTableView.getSelectionModel().clearSelection();
        SSCWorkspace.fileNameTextField.setText("");
        SSCWorkspace.pathTextField.setText("");
        SSCWorkspace.captionTextField.setText("");
        SSCWorkspace.originalWidthTextField.setText("");
        SSCWorkspace.originalHeightTextField.setText("");
        SSCWorkspace.currentHeightSlider.setValue(0);
        SSCWorkspace.currentWidthSlider.setValue(0);
        SSCWorkspace.toggleRemoveImageButton();
        SSCWorkspace.toggleUserInputFields();
    }
    
    // Controller method that handles updating the variables of a selected item
    public void handleUpdate(){
        SlideshowCreatorWorkspace SSCWorkspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        if(!SSCWorkspace.slidesTableView.getSelectionModel().isEmpty()){ // if a slide is selected
            Slide selectedSlide = (Slide)SSCWorkspace.slidesTableView.getSelectionModel().getSelectedItem();
            selectedSlide.setCurrentHeight((int)SSCWorkspace.currentHeightSlider.getValue());
            selectedSlide.setCurrentWidth((int)SSCWorkspace.currentWidthSlider.getValue());
            selectedSlide.setCaption(SSCWorkspace.captionTextField.getText());
            SSCWorkspace.toggleUpdateButton(false);
            enableSave();
        }
    }
    
    // Helper method which marks a file as edited (and thus eligible for saving)
    public void enableSave(){
        AppFileController frameworkController = app.getGUI().getFileController();
        frameworkController.markAsEdited(app.getGUI());
    }
    
    // THIS HELPER METHOD LOADS AN IMAGE SO WE CAN SEE ITS SIZE
    private Image loadImage(String imagePath) throws MalformedURLException {
	File file = new File(imagePath);
	URL fileURL = file.toURI().toURL();
	Image image = new Image(fileURL.toExternalForm());
	return image;
    }
}