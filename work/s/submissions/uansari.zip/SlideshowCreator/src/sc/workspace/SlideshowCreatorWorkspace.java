package sc.workspace;

import djf.components.AppDataComponent;
import djf.components.AppWorkspaceComponent;
import static djf.ui.AppGUI.CLASS_BORDERED_PANE;
import java.net.MalformedURLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import sc.SlideshowCreatorApp;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Slider;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javax.swing.plaf.synth.Region;
import properties_manager.PropertiesManager;
import static sc.SlideshowCreatorProp.ADD_ALL_IMAGES_BUTTON_TEXT;
import static sc.SlideshowCreatorProp.ADD_IMAGE_BUTTON_TEXT;
import static sc.SlideshowCreatorProp.CAPTION_PROMPT_TEXT;
import static sc.SlideshowCreatorProp.CURRENT_HEIGHT_COLUMN_TEXT;
import static sc.SlideshowCreatorProp.CURRENT_HEIGHT_PROMPT_TEXT;
import static sc.SlideshowCreatorProp.CURRENT_WIDTH_COLUMN_TEXT;
import static sc.SlideshowCreatorProp.CURRENT_WIDTH_PROMPT_TEXT;
import static sc.SlideshowCreatorProp.FILE_NAME_COLUMN_TEXT;
import static sc.SlideshowCreatorProp.FILE_NAME_PROMPT_TEXT;
import static sc.SlideshowCreatorProp.ORIGINAL_HEIGHT_PROMPT_TEXT;
import static sc.SlideshowCreatorProp.ORIGINAL_WIDTH_PROMPT_TEXT;
import static sc.SlideshowCreatorProp.PATH_PROMPT_TEXT;
import static sc.SlideshowCreatorProp.REMOVE_IMAGE_BUTTON_TEXT;
import static sc.SlideshowCreatorProp.UPDATE_BUTTON_TEXT;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;
import static sc.style.SlideshowCreatorStyle.CLASS_EDIT_BUTTON;
import static sc.style.SlideshowCreatorStyle.CLASS_EDIT_SLIDER;
import static sc.style.SlideshowCreatorStyle.CLASS_EDIT_TEXT_FIELD;
import static sc.style.SlideshowCreatorStyle.CLASS_PROMPT_LABEL;
import static sc.style.SlideshowCreatorStyle.CLASS_SLIDES_TABLE;
import static sc.style.SlideshowCreatorStyle.CLASS_UPDATE_BUTTON;

/**
 * This class serves as the workspace component for the TA Manager
 * application. It provides all the user interface controls in 
 * the workspace area.
 * 
 * @author Richard McKenna
 */
public class SlideshowCreatorWorkspace extends AppWorkspaceComponent {
    // THIS PROVIDES US WITH ACCESS TO THE APP COMPONENTS
    SlideshowCreatorApp app;

    // THIS PROVIDES RESPONSES TO INTERACTIONS WITH THIS WORKSPACE
    SlideshowCreatorController controller;

    // NOTE THAT EVERY CONTROL IS PUT IN A BOX TO HELP WITH ALIGNMENT
    HBox editImagesToolbar;
    Button addAllImagesInDirectoryButton;
    Button addImageButton;
    Button removeImageButton;
    
    // FOR THE SLIDES TABLE
    ScrollPane slidesTableScrollPane;
    TableView<Slide> slidesTableView;
    TableColumn<Slide, StringProperty> fileNameColumn;
    TableColumn<Slide, IntegerProperty> currentWidthColumn;
    TableColumn<Slide, IntegerProperty> currentHeightColumn;

    // THE EDIT PANE
    GridPane editPane;
    Label fileNamePromptLabel;
    TextField fileNameTextField;
    Label pathPromptLabel;
    TextField pathTextField;
    Label captionPromptLabel;
    TextField captionTextField;
    Label originalWidthPromptLabel;
    TextField originalWidthTextField;
    Label originalHeightPromptLabel;
    TextField originalHeightTextField;
    Label currentWidthPromptLabel;
    Slider currentWidthSlider;
    Label currentHeightPromptLabel;
    Slider currentHeightSlider;
    Button updateButton;
    
    /**
     * The constructor initializes the user interface for the
     * workspace area of the application.
     */
    public SlideshowCreatorWorkspace(SlideshowCreatorApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;

        // WE'LL NEED THIS TO GET LANGUAGE PROPERTIES FOR OUR UI
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        
        // LAYOUT THE APP
        initLayout();
        
        // HOOK UP THE CONTROLLERS
        initControllers();
        
        // AND INIT THE STYLE FOR THE WORKSPACE
        initStyle();
    }
    
    private void initLayout() {
        // WE'LL USE THIS TO GET UI TEXT
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        
        // FIRST MAKE ALL THE COMPONENTS
        editImagesToolbar = new HBox();
        addAllImagesInDirectoryButton = new Button(props.getProperty(ADD_ALL_IMAGES_BUTTON_TEXT));
        addImageButton = new Button(props.getProperty(ADD_IMAGE_BUTTON_TEXT));
        removeImageButton = new Button(props.getProperty(REMOVE_IMAGE_BUTTON_TEXT));
        slidesTableScrollPane = new ScrollPane();
        slidesTableView = new TableView();
        fileNameColumn = new TableColumn(props.getProperty(FILE_NAME_COLUMN_TEXT));
        currentWidthColumn = new TableColumn(props.getProperty(CURRENT_WIDTH_COLUMN_TEXT));
        currentHeightColumn = new TableColumn(props.getProperty(CURRENT_HEIGHT_COLUMN_TEXT));
        editPane = new GridPane();
        fileNamePromptLabel = new Label(props.getProperty(FILE_NAME_PROMPT_TEXT));
        fileNameTextField = new TextField();
        pathPromptLabel = new Label(props.getProperty(PATH_PROMPT_TEXT));
        pathTextField = new TextField();
        captionPromptLabel = new Label(props.getProperty(CAPTION_PROMPT_TEXT));
        captionTextField = new TextField();
        originalWidthPromptLabel = new Label(props.getProperty(ORIGINAL_WIDTH_PROMPT_TEXT));
        originalWidthTextField = new TextField();
        originalHeightPromptLabel = new Label(props.getProperty(ORIGINAL_HEIGHT_PROMPT_TEXT));
        originalHeightTextField = new TextField();
        
        currentWidthPromptLabel = new Label(props.getProperty(CURRENT_WIDTH_PROMPT_TEXT));
        currentWidthSlider = new Slider();
        currentWidthSlider.setMax(1000);
        currentWidthSlider.setMin(0);
        currentWidthSlider.setShowTickMarks(true);
        currentWidthSlider.setShowTickLabels(true);
        currentWidthSlider.showTickLabelsProperty();
        currentWidthSlider.showTickMarksProperty();
        currentWidthSlider.blockIncrementProperty();
        currentWidthSlider.setMajorTickUnit(200);
        currentWidthSlider.setMinorTickCount(3);
        currentWidthSlider.setBlockIncrement(50);
        currentWidthSlider.snapToTicksProperty();
        currentWidthSlider.setSnapToTicks(true);
        currentWidthSlider.setPadding(new Insets(0,5,0,0));
       
        currentHeightPromptLabel = new Label(props.getProperty(CURRENT_HEIGHT_PROMPT_TEXT));
        currentHeightSlider = new Slider();
        currentHeightSlider.setMax(1000);
        currentHeightSlider.setMin(0);
        currentHeightSlider.setMajorTickUnit(200);
        currentHeightSlider.setMinorTickCount(3);
        currentHeightSlider.showTickLabelsProperty();
        currentHeightSlider.showTickMarksProperty();
        currentHeightSlider.snapToTicksProperty();
        currentHeightSlider.setBlockIncrement(50);
        currentHeightSlider.setShowTickMarks(true);
        currentHeightSlider.setShowTickLabels(true);
        currentHeightSlider.setSnapToTicks(true);
        currentHeightSlider.setPadding(new Insets(0,5,0,0));

        
        updateButton = new Button(props.getProperty(UPDATE_BUTTON_TEXT));
        
        updateButton.setDisable(true);
        addAllImagesInDirectoryButton.setDisable(true);
        addImageButton.setDisable(true);
        removeImageButton.setDisable(true);
        
        
        
        
        // ARRANGE THE TABLE
        fileNameColumn = new TableColumn(props.getProperty(FILE_NAME_COLUMN_TEXT));
        currentWidthColumn = new TableColumn(props.getProperty(CURRENT_WIDTH_COLUMN_TEXT));
        currentHeightColumn = new TableColumn(props.getProperty(CURRENT_HEIGHT_COLUMN_TEXT));
        slidesTableView.getColumns().add(fileNameColumn);
        slidesTableView.getColumns().add(currentWidthColumn);
        slidesTableView.getColumns().add(currentHeightColumn);
        fileNameColumn.prefWidthProperty().bind(slidesTableView.widthProperty().divide(2));
        currentWidthColumn.prefWidthProperty().bind(slidesTableView.widthProperty().divide(4));
        currentHeightColumn.prefWidthProperty().bind(slidesTableView.widthProperty().divide(4));
        fileNameColumn.setCellValueFactory(
                new PropertyValueFactory<Slide, StringProperty>("fileName")
        );
        currentWidthColumn.setCellValueFactory(
                new PropertyValueFactory<Slide, IntegerProperty>("currentWidth")
        );
        currentHeightColumn.setCellValueFactory(
                new PropertyValueFactory<Slide, IntegerProperty>("CurrentHeight")
        );
        // HOOK UP THE TABLE TO THE DATA
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        ObservableList<Slide> model = data.getSlides();
        slidesTableView.setItems(model);
        
        // THEM ORGANIZE THEM
        editImagesToolbar.getChildren().add(addAllImagesInDirectoryButton);
        editImagesToolbar.getChildren().add(addImageButton);
        editImagesToolbar.getChildren().add(removeImageButton);
        slidesTableScrollPane.setContent(slidesTableView);
        editPane.add(fileNamePromptLabel, 0, 0);
        editPane.add(fileNameTextField, 1, 0);
        editPane.add(pathPromptLabel, 0, 1);
        editPane.add(pathTextField, 1, 1);
        editPane.add(captionPromptLabel, 0, 2);
        editPane.add(captionTextField, 1, 2);
        editPane.add(originalWidthPromptLabel, 0, 3);
        editPane.add(originalWidthTextField, 1, 3);
        editPane.add(originalHeightPromptLabel, 0, 4);
        editPane.add(originalHeightTextField, 1, 4);
        editPane.add(currentWidthPromptLabel, 0, 5);
        editPane.add(currentWidthSlider, 1, 5);
        editPane.add(currentHeightPromptLabel, 0, 6);
        editPane.add(currentHeightSlider, 1, 6);
        editPane.add(updateButton, 0, 7);
        
        // DISABLE THE DISPLAY TEXT FIELDS
        fileNameTextField.setDisable(true);
        pathTextField.setDisable(true);
        originalWidthTextField.setDisable(true);
        originalHeightTextField.setDisable(true);
        
        captionTextField.setDisable(true);
        currentHeightSlider.setDisable(true);
        currentWidthSlider.setDisable(true);
        
        // AND THEN PUT EVERYTHING INSIDE THE WORKSPACE
        app.getGUI().getTopToolbarPane().getChildren().add(editImagesToolbar);
        BorderPane workspaceBorderPane = new BorderPane();
        workspaceBorderPane.setCenter(slidesTableScrollPane);
        slidesTableScrollPane.setFitToWidth(true);
        slidesTableScrollPane.setFitToHeight(true);
        workspaceBorderPane.setRight(editPane);
        
        // AND SET THIS AS THE WORKSPACE PANE
        workspace = workspaceBorderPane;
        
    }
    
    private void initControllers() {
        // NOW LET'S SETUP THE EVENT HANDLING
        controller = new SlideshowCreatorController(app);

        addAllImagesInDirectoryButton.setOnAction((ActionEvent e) -> {
            try {
                controller.handleAddAllImagesInDirectory();
            } catch (MalformedURLException ex) {
                Logger.getLogger(SlideshowCreatorWorkspace.class.getName()).log(Level.SEVERE, null, ex);
            }
            removeImageButton.setDisable(true);
            disableFields();
        });
        addImageButton.setOnAction(e->{
            controller.handleAddSingleImage();
        });
        removeImageButton.setOnAction(e->{
            controller.handleRemoveSlide();
            removeImageButton.setDisable(true);
            disableFields();
            disableUpdate();
        });
        slidesTableView.getSelectionModel().selectedItemProperty().addListener(e->
        {
            controller.handleSelectImage();
            disableUpdate();
            enableFields();
            removeImageButton.setDisable(false);
        });
        updateButton.setOnAction((ActionEvent e) ->{
            controller.handleUpdateSlide();
            disableUpdate();
            disableFields();
            removeImageButton.setDisable(true);
        });
        
        captionTextField.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                enableUpdate();  
            }
        });
        currentWidthSlider.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                enableUpdate();  
            }
        });
        currentHeightSlider.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                enableUpdate();            
            }
        });
        
       
    }
    
    
    // WE'LL PROVIDE AN ACCESSOR METHOD FOR EACH VISIBLE COMPONENT
    // IN CASE A CONTROLLER OR STYLE CLASS NEEDS TO CHANGE IT
    
    private void initStyle() {
        editImagesToolbar.getStyleClass().add(CLASS_BORDERED_PANE);
        addAllImagesInDirectoryButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        addImageButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        removeImageButton.getStyleClass().add(CLASS_EDIT_BUTTON);

        // THE SLIDES TABLE
        slidesTableView.getStyleClass().add(CLASS_SLIDES_TABLE);
        for (TableColumn tc : slidesTableView.getColumns())
            tc.getStyleClass().add(CLASS_SLIDES_TABLE);
        
        editPane.getStyleClass().add(CLASS_BORDERED_PANE);
        fileNamePromptLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
        fileNameTextField.getStyleClass().add(CLASS_EDIT_TEXT_FIELD);
        pathPromptLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
        pathTextField.getStyleClass().add(CLASS_EDIT_TEXT_FIELD);
        captionPromptLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
        captionTextField.getStyleClass().add(CLASS_EDIT_TEXT_FIELD);
        originalWidthPromptLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
        originalWidthTextField.getStyleClass().add(CLASS_EDIT_TEXT_FIELD);
        originalHeightPromptLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
        originalHeightTextField.getStyleClass().add(CLASS_EDIT_TEXT_FIELD);
        currentWidthPromptLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
        currentWidthSlider.getStyleClass().add(CLASS_EDIT_SLIDER);
        currentHeightPromptLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
        currentHeightSlider.getStyleClass().add(CLASS_EDIT_SLIDER);
        updateButton.getStyleClass().add(CLASS_UPDATE_BUTTON);
    }

    @Override
    public void resetWorkspace() {
        slidesTableView.refresh();
        clearFields();
        addAllImagesInDirectoryButton.setDisable(false);
        addImageButton.setDisable(false);
        removeImageButton.setDisable(true);
        
    }
    @Override
    public void reloadWorkspace(AppDataComponent dataComponent) {
        slidesTableView.refresh();
    }
    public void enableUpdate(){
        if(!originalWidthTextField.getText().isEmpty())
        updateButton.setDisable(false);
    }
    public void disableUpdate(){
        updateButton.setDisable(true);
    }
    public void enableEditToolbar(){
        if(!(workspaceActivated == false)){
            addAllImagesInDirectoryButton.setDisable(false);
            addImageButton.setDisable(false);
            removeImageButton.setDisable(false);
        }
    }
    
    public void enableFields(){
        captionTextField.setDisable(false);
        currentHeightSlider.setDisable(false);
        currentWidthSlider.setDisable(false);
    }
    public void disableFields(){
        captionTextField.setDisable(true);
        currentHeightSlider.setDisable(true);
        currentWidthSlider.setDisable(true);
    }
    public void clearFields(){
        pathTextField.clear();
        fileNameTextField.clear();
        captionTextField.clear();
        originalWidthTextField.clear();
        originalHeightTextField.clear();
        currentHeightSlider.setValue(0);
        currentWidthSlider.setValue(0);
        
    }
    public TableView getImageTable(){
        return slidesTableView;
    }
    
    public Button getRemoveButton(){
        return removeImageButton;
    }
    
    public TextField getFileNameTextField(){
        return fileNameTextField;
    }
    
    public TextField getPathTextField(){
        return pathTextField;
    }
    
    public TextField getCaptionTextField(){
        return captionTextField;
    }
    
    public TextField getOrigWidthTextField(){
        return originalWidthTextField;
    }
    
    public TextField getOrigHeightTextField(){
        return originalHeightTextField;
    }
    
    public Slider getWidthSlider(){
        return currentWidthSlider;
    }
    
    public Slider getHeightSlider(){
        return currentHeightSlider;
    }
    //public TextField get
    
//    GridPane editPane;
//    Label fileNamePromptLabel;
//    TextField fileNameTextField;
//    Label pathPromptLabel;
//    TextField pathTextField;
//    Label captionPromptLabel;
//    TextField captionTextField;
//    Label originalWidthPromptLabel;
//    TextField originalWidthTextField;
//    Label originalHeightPromptLabel;
//    TextField originalHeightTextField;
//    Label currentWidthPromptLabel;
//    Slider currentWidthSlider;
//    Label currentHeightPromptLabel;
//    Slider currentHeightSlider;
//    Button updateButton;
}
