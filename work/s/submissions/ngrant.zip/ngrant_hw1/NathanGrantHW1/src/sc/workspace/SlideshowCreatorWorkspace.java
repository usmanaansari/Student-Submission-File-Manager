package sc.workspace;

import djf.components.AppDataComponent;
import djf.components.AppWorkspaceComponent;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import properties_manager.PropertiesManager;
import sc.SlideshowCreatorApp;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;

import static djf.ui.AppGUI.CLASS_BORDERED_PANE;
import static sc.SlideshowCreatorProp.*;
import static sc.style.SlideshowCreatorStyle.*;

/**
 * This class serves as the workspace component for the TA Manager
 * application. It provides all the user interface controls in 
 * the workspace area.
 * 
 * @author Richard McKenna
 */
public class SlideshowCreatorWorkspace extends AppWorkspaceComponent {
    // THIS PROVIDES US WITH ACCESS TO THE APP COMPONENTS
    SlideshowCreatorApp app;

    // THIS PROVIDES RESPONSES TO INTERACTIONS WITH THIS WORKSPACE
    SlideshowCreatorController controller;

    // NOTE THAT EVERY CONTROL IS PUT IN A BOX TO HELP WITH ALIGNMENT
    HBox editImagesToolbar;
    Button addAllImagesInDirectoryButton;
    Button addImageButton;
    Button removeImageButton;
    
    // FOR THE SLIDES TABLE
    ScrollPane slidesTableScrollPane;
    TableView<Slide> slidesTableView;
    TableColumn<Slide, StringProperty> fileNameColumn;
    TableColumn<Slide, IntegerProperty> currentWidthColumn;
    TableColumn<Slide, IntegerProperty> currentHeightColumn;

    // THE EDIT PANE
    GridPane editPane;
    Label fileNamePromptLabel;
    TextField fileNameTextField;
    Label pathPromptLabel;
    TextField pathTextField;
    Label captionPromptLabel;
    TextField captionTextField;
    Label originalWidthPromptLabel;
    TextField originalWidthTextField;
    Label originalHeightPromptLabel;
    TextField originalHeightTextField;
    Label currentWidthPromptLabel;
    Slider currentWidthSlider;
    Label currentHeightPromptLabel;
    Slider currentHeightSlider;
    Button updateButton;
    private SlideshowCreatorData controller2;

    public Slide rowdata;


    /**
     * The constructor initializes the user interface for the
     * workspace area of the application.
     */
    public SlideshowCreatorWorkspace(SlideshowCreatorApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
        controller = new SlideshowCreatorController(app);

        // WE'LL NEED THIS TO GET LANGUAGE PROPERTIES FOR OUR UI
        PropertiesManager props = PropertiesManager.getPropertiesManager();


        // LAYOUT THE APP
        initLayout();
        
        // HOOK UP THE CONTROLLERS
        initControllers();
        
        // AND INIT THE STYLE FOR THE WORKSPACE
        initStyle();
    }
    
    private void initLayout() {
        // WE'LL USE THIS TO GET UI TEXT
        PropertiesManager props = PropertiesManager.getPropertiesManager();


        // FIRST MAKE ALL THE COMPONENTS
        editImagesToolbar = new HBox();
        addAllImagesInDirectoryButton = new Button(props.getProperty(ADD_ALL_IMAGES_BUTTON_TEXT));
        addImageButton = new Button(props.getProperty(ADD_IMAGE_BUTTON_TEXT));
        removeImageButton = new Button(props.getProperty(REMOVE_IMAGE_BUTTON_TEXT));
        slidesTableScrollPane = new ScrollPane();
        slidesTableView = new TableView();
        fileNameColumn = new TableColumn(props.getProperty(FILE_NAME_COLUMN_TEXT));
        currentWidthColumn = new TableColumn(props.getProperty(CURRENT_WIDTH_COLUMN_TEXT));
        currentHeightColumn = new TableColumn(props.getProperty(CURRENT_HEIGHT_COLUMN_TEXT));
        editPane = new GridPane();
        fileNamePromptLabel = new Label(props.getProperty(FILE_NAME_PROMPT_TEXT));
        fileNameTextField = new TextField();
        pathPromptLabel = new Label(props.getProperty(PATH_PROMPT_TEXT));
        pathTextField = new TextField();
        captionPromptLabel = new Label(props.getProperty(CAPTION_PROMPT_TEXT));
        captionTextField = new TextField();
        originalWidthPromptLabel = new Label(props.getProperty(ORIGINAL_WIDTH_PROMPT_TEXT));
        originalWidthTextField = new TextField();
        originalHeightPromptLabel = new Label(props.getProperty(ORIGINAL_HEIGHT_PROMPT_TEXT));
        originalHeightTextField = new TextField();
        currentWidthPromptLabel = new Label(props.getProperty(CURRENT_WIDTH_PROMPT_TEXT));

        currentWidthSlider = new Slider();
        currentWidthSlider.setMax(1000);
        currentWidthSlider.setMin(0);
        currentWidthSlider.setShowTickMarks(true);
        currentWidthSlider.setBlockIncrement(200);
        currentWidthSlider.setMajorTickUnit(200);
        currentWidthSlider.setShowTickLabels(true);

        currentHeightPromptLabel = new Label(props.getProperty(CURRENT_HEIGHT_PROMPT_TEXT));
        currentHeightSlider = new Slider();
        currentHeightSlider.setMax(1000);
        currentHeightSlider.setMin(0);
        //currentHeightSlider.showTickLabelsProperty();
        currentHeightSlider.setShowTickMarks(true);
        currentHeightSlider.setBlockIncrement(200);
        currentHeightSlider.setMajorTickUnit(200);
        currentHeightSlider.setShowTickLabels(true);




        updateButton = new Button(props.getProperty(UPDATE_BUTTON_TEXT));
        
        // ARRANGE THE TABLE
        fileNameColumn = new TableColumn(props.getProperty(FILE_NAME_COLUMN_TEXT));
        currentWidthColumn = new TableColumn(props.getProperty(CURRENT_WIDTH_COLUMN_TEXT));
        currentHeightColumn = new TableColumn(props.getProperty(CURRENT_HEIGHT_COLUMN_TEXT));
        slidesTableView.getColumns().add(fileNameColumn);
        slidesTableView.getColumns().add(currentWidthColumn);
        slidesTableView.getColumns().add(currentHeightColumn);
        fileNameColumn.prefWidthProperty().bind(slidesTableView.widthProperty().divide(2));
        currentWidthColumn.prefWidthProperty().bind(slidesTableView.widthProperty().divide(4));
        currentHeightColumn.prefWidthProperty().bind(slidesTableView.widthProperty().divide(4));
        fileNameColumn.setCellValueFactory(
                new PropertyValueFactory<Slide, StringProperty>("fileName")
        );
        currentWidthColumn.setCellValueFactory(
                new PropertyValueFactory<Slide, IntegerProperty>("currentWidth")
        );
        currentHeightColumn.setCellValueFactory(
                new PropertyValueFactory<Slide, IntegerProperty>("CurrentHeight")
        );
        // HOOK UP THE TABLE TO THE DATA

        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        ObservableList<Slide> model = data.getSlides();
        slidesTableView.setItems(model);

        /*
        if(controller.getRemoveRowTest()==true){

            slidesTableView.setRowFactory( tv-> {
                TableRow<Slide> tableRow = new TableRow<Slide>();


                controller2 = (SlideshowCreatorData) app.getDataComponent();
                tableRow.setOnMouseClicked(r -> {
                    if (r.getClickCount() == 1) {
                        Slide rowdata = tableRow.getItem();
                        String fileN = rowdata.getFileName();
                        String pathN = rowdata.getPath();

                        String caption = rowdata.getCaption();
                        Integer originalHNum = rowdata.getOriginalHeight();
                        Integer originalWNum = rowdata.getOriginalWidth();
                        //tableRow.getItem().remove();
                        controller2.removeSlide(fileN, pathN, caption, originalHNum, originalWNum);
                        // controller.remo

                        controller.setRemoveRow(true);
                    }
                });

                return tableRow;
            });
        }
        else {

            slidesTableView.setRowFactory(ev -> {
                TableRow<Slide> tableRow = new TableRow<Slide>();
                tableRow.setOnMouseClicked(e -> {
                    if (e.getClickCount() == 1) {
                        Slide rowdata = tableRow.getItem();

                        getFileNameTextField().setText(rowdata.getFileName());
                        getPathTextField().setText(rowdata.getPath());
                        getCaptionTextField().setText(rowdata.getCaption());
                        //getCaptionTextField().setText(rowdata.);
                        getOriginalHeightTextField().setText("200");
                        getOriginalWidthTextField().setText("200");

                    }
                });
                return tableRow;

            });
        }
*/

        slidesTableView.setRowFactory( tv-> {
                    TableRow<Slide> tableRow = new TableRow<Slide>();


                    controller2 = (SlideshowCreatorData) app.getDataComponent();
                    tableRow.setOnMouseClicked(r -> {
                        
                        if (controller.getRemoveRowTest() == true) {
                            if (r.getClickCount() == 1) {
                                rowdata = tableRow.getItem();
                                String fileN = rowdata.getFileName();
                                String pathN = rowdata.getPath();

                                String caption = rowdata.getCaption();
                                Integer originalHNum = rowdata.getOriginalHeight();
                                Integer originalWNum = rowdata.getOriginalWidth();
                                //tableRow.getItem().remove();
                                controller2.removeSlide(fileN, pathN, caption, originalHNum, originalWNum);
                                // controller.remo

                                controller.setRemoveRow(false);

                                //controller.
                            }
                        } else {
                            if (r.getClickCount() == 1) {
                                rowdata = tableRow.getItem();
                                //controller.getGui().getTopToolb
                                addAllImagesInDirectoryButton.setDisable(true);
                                

                                getFileNameTextField().setText(rowdata.getFileName());
                                getPathTextField().setText(rowdata.getPath());
                                getCaptionTextField().setText(rowdata.getCaption());
                                //getCaptionTextField().setText(rowdata.);
                                getOriginalHeightTextField().setText("200");
                                getOriginalWidthTextField().setText("200");

                                //setCurrentWidthSlider((int)rowdata.getOriginalWidth());
                                setWidthCaption(rowdata.getOriginalWidth());
                                setHeighCaption(rowdata.getOriginalHeight());
                                
                                
                                 addAllImagesInDirectoryButton.setDisable(false);

                            }
                        }
                        
                        //addAllImagesInDirectoryButton.setDisable(false);
                       // return tableRow;
                    });
                        return tableRow;
                });



        // THEM ORGANIZE THEM
        editImagesToolbar.getChildren().add(addAllImagesInDirectoryButton);
        editImagesToolbar.getChildren().add(addImageButton);
        editImagesToolbar.getChildren().add(removeImageButton);
        slidesTableScrollPane.setContent(slidesTableView);
        editPane.add(fileNamePromptLabel, 0, 0);
        editPane.add(fileNameTextField, 1, 0);
        editPane.add(pathPromptLabel, 0, 1);
        editPane.add(pathTextField, 1, 1);
        editPane.add(captionPromptLabel, 0, 2);
        editPane.add(captionTextField, 1, 2);
        editPane.add(originalWidthPromptLabel, 0, 3);
        editPane.add(originalWidthTextField, 1, 3);
        editPane.add(originalHeightPromptLabel, 0, 4);
        editPane.add(originalHeightTextField, 1, 4);
        editPane.add(currentWidthPromptLabel, 0, 5);
        editPane.add(currentWidthSlider, 1, 5);
        editPane.add(currentHeightPromptLabel, 0, 6);
        editPane.add(currentHeightSlider, 1, 6);
        editPane.add(updateButton, 0, 7);
        
        // DISABLE THE DISPLAY TEXT FIELDS
        fileNameTextField.setDisable(true);
        pathTextField.setDisable(true);
        originalWidthTextField.setDisable(true);
        originalHeightTextField.setDisable(true);
        
        // AND THEN PUT EVERYTHING INSIDE THE WORKSPACE
        app.getGUI().getTopToolbarPane().getChildren().add(editImagesToolbar);
        BorderPane workspaceBorderPane = new BorderPane();
        workspaceBorderPane.setCenter(slidesTableScrollPane);
        slidesTableScrollPane.setFitToWidth(true);
        slidesTableScrollPane.setFitToHeight(true);
        workspaceBorderPane.setRight(editPane);
        
        // AND SET THIS AS THE WORKSPACE PANE
        workspace = workspaceBorderPane;
    }

    
    private void initControllers() {
        // NOW LET'S SETUP THE EVENT HANDLI
        controller = new SlideshowCreatorController(app);

        addImageButton.setOnAction(e -> {
            controller.addImagesInDirectory();

        });

        removeImageButton.setOnAction(e -> {
            // controller.re
            controller.removeImagesInDirectory(slidesTableView);

        });

        addAllImagesInDirectoryButton.setOnAction(e -> {
            controller.handleAddAllImagesInDirectory();
        });

        updateButton.setOnAction(e -> {

/*
            TableRow<Slide> tableRow = new TableRow<Slide>();
            Slide rowdata = tableRow.getItem();
            controller.updateInfo(rowdata);

*/


            controller2 = (SlideshowCreatorData) app.getDataComponent();


            //Slide rowdata = tableRow.getItem();

            Slider WidthSlider = getCurrentWidthSlider();
            Slider HeightSlider = getCurrentHeightSlider();
            TextField caption = getCaptionTextField();

            double widthSlidervalue = WidthSlider.getValue();
            double heightSlidervalue = HeightSlider.getValue();
            String captionText = (String) caption.getText();

            //rowdata.setCaption(captionText);
            //rowdata.setCurrentHeight((int) heightSlidervalue);
            rowdata.setOriginalHeight((int) heightSlidervalue);
            rowdata.setOriginalWidth((int) widthSlidervalue);
            rowdata.setCaption(captionText);


            setWidthCaption(rowdata.getOriginalWidth());
            setHeighCaption(rowdata.getOriginalHeight());
            setCaptionTextField(rowdata.getCaption());

                            /*
                            getFileNameTextField().setText(rowdata.getFileName());
                            getPathTextField().setText(rowdata.getPath());
                            getCaptionTextField().setText(rowdata.getCaption());
                            //getCaptionTextField().setText(rowdata.);
                            getOriginalHeightTextField().setText("200");
                            getOriginalWidthTextField().setText("200");

                            */


        });
    }

    public TextField getFileNameTextField(){

        return fileNameTextField;
    }

    public TextField getPathTextField (){

        return pathTextField;
    }

    public TextField getCaptionTextField(){

        return captionTextField;
    }

    public TextField getOriginalWidthTextField (){

        return originalWidthTextField;
    }

    public TextField getOriginalHeightTextField (){

        return originalHeightTextField;
    }

    public TableView<Slide> getSlideTableView(){

        return slidesTableView;
    }

    public Slider getCurrentWidthSlider(){

        return currentWidthSlider;
    }

    public Slider getCurrentHeightSlider(){

        return currentHeightSlider;
    }

    public void setCaptionTextField(String text){

        captionTextField.setText(text);
    }

    public void setWidthCaption(double width){

        currentWidthSlider.setValue(width);
    }

    public void setHeighCaption(double height){

        currentHeightSlider.setValue(height);

    }



    // WE'LL PROVIDE AN ACCESSOR METHOD FOR EACH VISIBLE COMPONENT
    // IN CASE A CONTROLLER OR STYLE CLASS NEEDS TO CHANGE IT
    
    private void initStyle() {
        editImagesToolbar.getStyleClass().add(CLASS_BORDERED_PANE);
        addAllImagesInDirectoryButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        addImageButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        removeImageButton.getStyleClass().add(CLASS_EDIT_BUTTON);

        // THE SLIDES TABLE
        slidesTableView.getStyleClass().add(CLASS_SLIDES_TABLE);
        for (TableColumn tc : slidesTableView.getColumns())
            tc.getStyleClass().add(CLASS_SLIDES_TABLE);
        
        editPane.getStyleClass().add(CLASS_BORDERED_PANE);
        fileNamePromptLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
        fileNameTextField.getStyleClass().add(CLASS_EDIT_TEXT_FIELD);

                pathPromptLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
                pathTextField.getStyleClass().add(CLASS_EDIT_TEXT_FIELD);

        captionPromptLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
        captionTextField.getStyleClass().add(CLASS_EDIT_TEXT_FIELD);

                originalWidthPromptLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
                originalWidthTextField.getStyleClass().add(CLASS_EDIT_TEXT_FIELD);

        originalHeightPromptLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
        originalHeightTextField.getStyleClass().add(CLASS_EDIT_TEXT_FIELD);

        currentWidthPromptLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
        currentWidthSlider.getStyleClass().add(CLASS_EDIT_SLIDER);
        currentHeightPromptLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
        currentHeightSlider.getStyleClass().add(CLASS_EDIT_SLIDER);
        updateButton.getStyleClass().add(CLASS_UPDATE_BUTTON);
    }

    @Override
    public void resetWorkspace() {

    }
    
    @Override
    public void reloadWorkspace(AppDataComponent dataComponent) {

    }
}