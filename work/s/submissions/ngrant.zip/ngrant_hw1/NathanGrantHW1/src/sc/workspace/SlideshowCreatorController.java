package sc.workspace;

import djf.ui.AppGUI;
import djf.ui.AppMessageDialogSingleton;
import javafx.scene.control.Alert;
import javafx.scene.control.Slider;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import properties_manager.PropertiesManager;
import sc.SlideshowCreatorApp;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;
import sc.file.SlideshowCreatorFiles;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

/**
 * This class provides responses to all workspace interactions, meaning
 * interactions with the application controls not including the file
 * toolbar.
 * 
 * @author Richard McKenna
 * @version 1.0
 */
public class SlideshowCreatorController {
    // THE APP PROVIDES ACCESS TO OTHER COMPONENTS AS NEEDED
    SlideshowCreatorApp app;
    protected static final String APP_PATH_WORK="APP_PATH_WORK";
    protected static final String APP_IMAGE_DIR="APP_IMAGE_DIR";
    protected static final String INVALID_IMAGE_PATH_TITLE="Invalid Path Title";
    protected static final String INVALID_IMAGE_PATH_MESSAGE="Invalid Path Message";
    protected static ArrayList Imagecontainer=  new ArrayList();
    public static boolean removeRow=false;

    public SlideshowCreatorData controller;
    public SlideshowCreatorWorkspace controller2;
    public SlideshowCreatorFiles controller3;

    public Slide rowHolder;


    /**
     * Constructor, note that the app must already be constructed.
     */
    public SlideshowCreatorController(SlideshowCreatorApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
       
       // controller= new SlideshowCreatorWorkspace(app);
        controller= (SlideshowCreatorData) app.getDataComponent();
      //  controller2 = new SlideshowCreatorWorkspace(app);
       // controller2= (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
       // controller3= (SlideshowCreatorFiles) app.getFileComponent();

    }
    
    public AppGUI getGui(){
        return app.getGUI();
    }

    public void updateInfo(Slide rowdata){

        rowHolder=rowdata;


        controller2= (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
        controller3= (SlideshowCreatorFiles) app.getFileComponent();

        Slider WidthSlider= controller2.getCurrentWidthSlider();
        Slider HeightSlider= controller2.getCurrentHeightSlider();
        TextField caption= controller2.getCaptionTextField();

        double widthSlidervalue= WidthSlider.getValue();
        double heightSlidervalue= HeightSlider.getValue();
        String captionText= (String)caption.getText();

        //rowdata.setCaption(captionText);
        //rowdata.setCurrentHeight((int) heightSlidervalue);
        rowdata.setOriginalHeight((int) heightSlidervalue);
        rowdata.setOriginalWidth((int) widthSlidervalue);
        rowdata.setCaption(captionText);



        controller2.setWidthCaption(rowdata.getOriginalWidth());
        controller2.setHeighCaption(rowdata.getOriginalHeight());
        controller2.setCaptionTextField(rowdata.getCaption());

    }


    public void removeImagesInDirectory(TableView<Slide> slidesTableView){

        Alert alert= new Alert(Alert.AlertType.INFORMATION);

        alert.setTitle("Remove Image");
        alert.setHeaderText("Image Information");
        alert.setContentText("To remove a image click on the row of the image you want to remove");
        alert.showAndWait();


        setRemoveRow(true);

    }

    public boolean getRemoveRowTest(){

        return this.removeRow;
    }

    public void setRemoveRow(boolean test){
        this.removeRow=test;

    }
    public void addImagesInDirectory() {

        try {
            //Imagecontainer= new ArrayList();
            boolean imagetester=true;

            FileChooser dirChooser1 = new FileChooser();
            PropertiesManager props1 = PropertiesManager.getPropertiesManager();
            File test2 = new File(props1.getProperty(APP_IMAGE_DIR));

            dirChooser1.setInitialDirectory(test2);

            File dir = dirChooser1.showOpenDialog(app.getGUI().getWindow());
            //File dir = dirChooser1.showDialog(app.getGUI().getWindow());


            if (dir != null) {
                File files = dir.getAbsoluteFile();


                String path = files.getPath();
                String fileName = files.getName();
                String caption = "";
                Image slideShowImage2 = loadImage(files.getPath());
                //Image slideShowImage = loadImage(path);
                int originalWidth = (int) slideShowImage2.getWidth();
                int originalHeight = (int) slideShowImage2.getHeight();
                SlideshowCreatorData data = (SlideshowCreatorData) app.getDataComponent();

                if(Imagecontainer.size()==0) {
                    Imagecontainer.add(path);
                    data.addSlide(fileName, path, caption, originalWidth, originalHeight);
                }
                else {

                    for (int i = 0; i < Imagecontainer.size(); i++) {
                        String imagecontainer2 = (String) Imagecontainer.get(i);
                        if (imagecontainer2.compareTo(path) != 0) {
                            imagetester = false;
                        } else
                            imagetester = true;
                    }
                    if (imagetester == false) {
                        Imagecontainer.add(path);
                        data.addSlide(fileName, path, caption, originalWidth, originalHeight);
                    }
                    else{
                        Alert alert= new Alert(Alert.AlertType.INFORMATION);

                        alert.setTitle("Image already added");
                        alert.setHeaderText("Image Information");
                        alert.setContentText("Image that you picked has already been added before.");

                    }
                }
            }
        } catch(MalformedURLException exc){
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);

        }
    }




    // CONTROLLER METHOD THAT HANDLES ADDING A DIRECTORY OF IMAGES
    public void handleAddAllImagesInDirectory() {
        try {
            
            boolean skipperTest= false;

            // ASK THE USER TO SELECT A DIRECTORY
            DirectoryChooser dirChooser = new DirectoryChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            File test1= new File(props.getProperty(APP_PATH_WORK));

            dirChooser.setInitialDirectory(test1);

            File dir = dirChooser.showDialog(app.getGUI().getWindow());
            if (dir != null) {
                File[] files = dir.listFiles();
                for (File f : files) {
                    String fileName = f.getName();
                    if (fileName.toLowerCase().endsWith(".png") ||
                            fileName.toLowerCase().endsWith(".jpg") ||
                            fileName.toLowerCase().endsWith(".gif")) {
                        for(int i=0;i<returnImagineContainer().size();i++){
                            int size=returnImagineContainer().size();
                            
                            if(returnImagineContainer().get(i).toString().compareTo(f.getPath())==0){
                                skipperTest=true;
                                break;
                            }
                        }
                                if(skipperTest==false){
                                     String path = f.getPath();
                                     String caption = "";
                                     Image slideShowImage = loadImage(path);
                                     int originalWidth = (int)slideShowImage.getWidth();
                                     int originalHeight = (int)slideShowImage.getHeight();
                                     SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();

                                     Imagecontainer.add(path);
                                     data.addSlide(fileName, path, caption, originalWidth, originalHeight);
                                }
                                else{
                                    skipperTest=false;
                                    continue;
                                }
                                    //continue;
                    }
                }
            }
        }
        catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }
    
    // THIS HELPER METHOD LOADS AN IMAGE SO WE CAN SEE IT'S SIZE
    private Image loadImage(String imagePath) throws MalformedURLException {
	File file = new File(imagePath);
	URL fileURL = file.toURI().toURL();
	Image image = new Image(fileURL.toExternalForm());
	return image;
    }

    public ArrayList returnImagineContainer(){

        return Imagecontainer;
    }

}