package jtps.test;

/**
 *
 * @author McKillaGorilla
 */
public class Num {
    private int num = 0;
    
    public void setNum(int initNum) {
        num = initNum;
    }
    
    public int getNum() {
        return num;
    }
}
