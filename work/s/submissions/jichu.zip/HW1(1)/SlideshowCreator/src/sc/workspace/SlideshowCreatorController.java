package sc.workspace;

import djf.ui.AppMessageDialogSingleton;
import java.awt.Desktop;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import javafx.collections.ObservableList;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import properties_manager.PropertiesManager;
import sc.SlideshowCreatorApp;
import static sc.SlideshowCreatorProp.APP_PATH_WORK;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_MESSAGE;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_TITLE;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;
import sc.workspace.SlideshowCreatorWorkspace;

/**
 * This class provides responses to all workspace interactions, meaning
 * interactions with the application controls not including the file toolbar.
 *
 * @author Richard McKenna
 * @co-author Jiawei Chu
 * @version 1.0
 */
public class SlideshowCreatorController {

    // THE APP PROVIDES ACCESS TO OTHER COMPONENTS AS NEEDED
    SlideshowCreatorApp app;
//    final FileChooser fileChooser = new FileChooser();
//    private Desktop desktop = Desktop.getDesktop();

    /**
     * Constructor, note that the app must already be constructed.
     */
    public SlideshowCreatorController(SlideshowCreatorApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
    }

    // CONTROLLER METHOD THAT HANDLES ADDING A DIRECTORY OF IMAGES
    public void handleAddAllImagesInDirectory() {
        try {
            // ASK THE USER TO SELECT A DIRECTORY
            DirectoryChooser dirChooser = new DirectoryChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            dirChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            File dir = dirChooser.showDialog(app.getGUI().getWindow());
            if (dir != null) {
                File[] files = dir.listFiles();
                for (File f : files) {
                    String fileName = f.getName();
                    String filePath = f.getPath();
                    if (fileName.toLowerCase().endsWith(".png")
                            || fileName.toLowerCase().endsWith(".jpg")
                            || fileName.toLowerCase().endsWith(".gif")) {
                        String path = f.getPath();
                        String caption = "";
                        Image slideShowImage = loadImage(path);
                        int originalWidth = (int) slideShowImage.getWidth();
                        int originalHeight = (int) slideShowImage.getHeight();
                        SlideshowCreatorData data = (SlideshowCreatorData) app.getDataComponent();
                        boolean NoDuplicate = true;
                        for (Slide i : data.getSlides()) {
                            if (i.getFileName().equals(fileName) && i.getPath().equals(filePath)) {
                                NoDuplicate = false;
                                break;
                            }
                            NoDuplicate = true;
                        }
                        if (NoDuplicate == true) {
                             SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
                           // if (workspace.slidesTableView.getSelectionModel().getSelectedItems().isEmpty())
           // workspace.updateButton.setDisable(true);
                            app.getGUI().updateToolbarControls(false);
                             
//                             workspace.captionTextField.setText(null);
//                              if(workspace.pathTextField.getText()==null){
//workspace.removeImageButton.setDisable(true);}  
                            data.addSlide(fileName, path, caption, originalWidth, originalHeight);
//                          
//                            if(workspace.pathTextField.getText()==""){
//workspace.removeImageButton.setDisable(true);
//}       
                        }
                    }
                }
            }
        } catch (MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }

    //  Handle add image
    public void handleAddImages() {
        DirectoryChooser dirChooser = new DirectoryChooser();
        PropertiesManager props = PropertiesManager.getPropertiesManager();

        FileChooser fileChooser = new FileChooser();
        fileChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
        File selectedFile = fileChooser.showOpenDialog(null);

        try {
            String fileName = selectedFile.getName();
            String filePath = selectedFile.getPath();
            if (fileName.toLowerCase().endsWith(".png")
                    || fileName.toLowerCase().endsWith(".jpg")
                    || fileName.toLowerCase().endsWith(".gif")) {
                String path2 = selectedFile.getPath();
                String caption = "";
                Image slideShowImage = loadImage(path2);
                int originalWidth = (int) slideShowImage.getWidth();
                int originalHeight = (int) slideShowImage.getHeight();
                SlideshowCreatorData data = (SlideshowCreatorData) app.getDataComponent();
                boolean NoDuplicate = true;
                for (Slide i : data.getSlides()) {
                    if (i.getFileName().equals(fileName) && i.getPath().equals(filePath)) {
                        NoDuplicate = false;
                        break;
                    }
                    NoDuplicate = true;
                }
                if (NoDuplicate == true) {
//                    SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();      
//                    workspace.resetWorkspace();

                    data.addSlide(fileName, path2, caption, originalWidth, originalHeight);
                    SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
                    workspace.slidesTableView.getSelectionModel().select(data.getSlides().get(data.getSlides().size() - 1));
                    app.getGUI().updateToolbarControls(false);
//                    TableView<Slide> table = new TableView<>();
//                    TableView.TableViewSelectionModel<Slide> ssm = table.getSelectionModel();
//                     table.setSelectionModel(ssm);

                }
            }
        } catch (MalformedURLException murle) {
            PropertiesManager props2 = PropertiesManager.getPropertiesManager();
            String title = props2.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props2.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }

    }

    public void handleRemoveImages() {
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
        Slide s = workspace.getTableView().getSelectionModel().getSelectedItem();
        workspace.getTableView().getItems().remove(s);
        workspace.getTableView().getSelectionModel().clearSelection();
        workspace.fileNameTextField.setText(null);
        workspace.pathTextField.setText(null);
        workspace.originalWidthTextField.setText(null);
        workspace.originalHeightTextField.setText(null);
        workspace.captionTextField.setText(null);
        workspace.currentWidthSlider.setValue(200);
        workspace.currentHeightSlider.setValue(200);
        app.getGUI().updateToolbarControls(false);
        
//        if (workspace.slidesTableView.getSelectionModel().getSelectedItems()==null)
//            workspace.updateButton.setDisable(true);
//         if(workspace.pathTextField.getText()==null){
//workspace.removeImageButton.setDisable(true);}  
         
         
         
//  workspace.slidesTableView.getSelectionModel().selectedItemProperty().addListener((v, oldValue, NewValue) -> {
//          if(NewValue!=null)  {workspace.fileNameTextField.setText(NewValue.getFileName());
//           workspace.pathTextField.setText(NewValue.getPath());
//            workspace.originalHeightTextField.setText(NewValue.getOriginalHeight().toString());
//            workspace.captionTextField.setText(NewValue.getCaption().toString());
//            workspace.originalWidthTextField.setText(NewValue.getOriginalWidth().toString());}});
//        TableView<Slide> table = new TableView<>();
//        Slide selectedItem = table.getSelectionModel().getSelectedItem();
//       
//       table.getItems().remove(selectedItem);

//        SlideshowCreatorWorkspace workspace = new SlideshowCreatorWorkspace();
//        TableView<Slide> viewController = workspace.getTableView();
//        ObservableList<Slide> listController = workspace.model2;
//        int selectIndex = viewController.getSelectionModel().getSelectedIndex();
//        Slide items = viewController.getSelectionModel().getSelectedItem();
//        listController.remove(selectIndex);
    }
// THIS HELPER METHOD LOADS AN IMAGE SO WE CAN SEE IT'S SIZE

    private Image loadImage(String imagePath) throws MalformedURLException {
        File file = new File(imagePath);
        URL fileURL = file.toURI().toURL();
        Image image = new Image(fileURL.toExternalForm());
        return image;
    }

    public void handleUpdate() {
 
           
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
        Slide s = workspace.getTableView().getSelectionModel().getSelectedItem();
//         System.out.println(s.getCaption()+"  V S  "+ workspace.captionTextField.getText());
//System.out.println(s.getCurrentHeight()+"  V S  "+(int)workspace.currentHeightSlider.getOnDragDetected());
//System.out.println();        
//if ((!s.getCaption().equals(workspace.captionTextField.getText()))
//                || (s.getCurrentHeight() != (int)workspace.currentHeightSlider.getValue()) || (s.getCurrentWidth() != (int)workspace.currentWidthSlider.getValue())) {
//            workspace.updateButton.setDisable(false);
//        }
        int h = (int) workspace.currentHeightSlider.getValue();
        int w = (int) workspace.currentWidthSlider.getValue();
        //  System.out.println(w);
        if((!s.getCaption().equals(workspace.captionTextField.getText()))
                ||(s.getCurrentHeight()!=(int)workspace.currentHeightSlider.getValue())||(s.getCurrentWidth()!=(int)workspace.currentWidthSlider.getValue())){
        
            s.setCaption(workspace.captionTextField.getText());
        workspace.getTableView().getSelectionModel().getSelectedItem().setCurrentHeight(h);
        workspace.getTableView().getSelectionModel().getSelectedItem().setCurrentWidth(w);
        workspace.slidesTableView.refresh();
        app.getGUI().updateToolbarControls(false);
        //workspace.updateButton.setDisable(false);}
       
           
//System.out.println(workspace.getTableView().getSelectionModel().getSelectedItem().getCurrentHeight());
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
