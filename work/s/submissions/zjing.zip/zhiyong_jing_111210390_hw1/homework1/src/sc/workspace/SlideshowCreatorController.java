package sc.workspace;

import djf.ui.AppMessageDialogSingleton;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import javafx.collections.ObservableList;
import javafx.scene.control.Slider;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import properties_manager.PropertiesManager;
import sc.SlideshowCreatorApp;
import static sc.SlideshowCreatorProp.APP_PATH_WORK;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_MESSAGE;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_TITLE;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;

/**
 * This class provides responses to all workspace interactions, meaning
 * interactions with the application controls not including the file
 * toolbar.
 * 
 * @author Richard McKenna
 * @version 1.0
 */
public class SlideshowCreatorController {
    // THE APP PROVIDES ACCESS TO OTHER COMPONENTS AS NEEDED
    SlideshowCreatorApp app;

    /**
     * Constructor, note that the app must already be constructed.
     */
    public SlideshowCreatorController(SlideshowCreatorApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
    }
    
    // CONTROLLER METHOD THAT HANDLES ADDING A DIRECTORY OF IMAGES
    public void handleAddAllImagesInDirectory() {
        try {
            // ASK THE USER TO SELECT A DIRECTORY
            DirectoryChooser dirChooser = new DirectoryChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            dirChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            File dir = dirChooser.showDialog(app.getGUI().getWindow());
            //System.out.println(dir.getPath());
            if (dir != null) {
                File[] files = dir.listFiles();
                for (File f : files) {
                    String fileName = f.getName();
                    if (fileName.toLowerCase().endsWith(".png") ||
                            fileName.toLowerCase().endsWith(".jpg") ||
                            fileName.toLowerCase().endsWith(".gif")) {
                        String path = f.getPath();
                        String caption = "";
                        Image slideShowImage = loadImage(path);
                        int originalWidth = (int)slideShowImage.getWidth();
                        int originalHeight = (int)slideShowImage.getHeight();
                        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                        data.addSlide(fileName, path, caption, originalWidth, originalHeight);
                    }
                }
            }
            app.getGUI().updateToolbarControls(false);

        }
        catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }
    
    public void handleAddIMage(){
        try{
            FileChooser dirChooser = new FileChooser();
            dirChooser.getExtensionFilters().addAll(new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"));
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            dirChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK))); 
            File dir = dirChooser.showOpenDialog(app.getGUI().getWindow());
            if (dir != null) {
                String fileName = dir.getName();
                String path = dir.getPath();
                String caption = "";
                Image slideShowImage = loadImage(path);
                int originalWidth = (int)slideShowImage.getWidth();
                int originalHeight = (int)slideShowImage.getHeight();
                SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                if(data.getSlides().isEmpty()){
                    data.addSlide(fileName, path, caption, originalWidth, originalHeight);
                    System.out.println(data.getSlides().get(0).getPath());
                }
               
                else{
                    for(Slide s:data.getSlides()){
                        if( !path.equals(s.getPath()))
                            data.addSlide(fileName, path, caption, originalWidth, originalHeight);
                }
                }   
            }
           app.getGUI().updateToolbarControls(false);
        }
        catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
        
    }
    public void handleRemoveImage(TableView<Slide> slidesTableView){
        Slide slide= slidesTableView.getSelectionModel().getSelectedItem();
        if(slide == null)
            return;
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        data.RemoveSlide(slide);
        
        slidesTableView.getSelectionModel().clearSelection();
        app.getGUI().updateToolbarControls(false);
    }
    public void showImage(TableView<Slide> slidesTabelView, TextField fileNameTextField
            , TextField pathTextField, TextField captionTextField
            , TextField originalWidthTextField,TextField originalHeightTextField
            , Slider currentHeightSlider, Slider currentWidthSlider)
    {
        Slide slide= slidesTabelView.getSelectionModel().getSelectedItem();
        if(slide == null)
            return;
        fileNameTextField.setText(slide.getFileName());
        pathTextField.setText(slide.getPath());
        captionTextField.setText(slide.getCaption());
        currentWidthSlider.setValue(slide.getCurrentWidth());
        originalWidthTextField.setText(slide.getCurrentWidth().toString());
        currentHeightSlider.setValue(slide.getCurrentHeight());
        originalHeightTextField.setText(slide.getCurrentHeight().toString());  
        // slidesTabelView.getSelectionModel().clearSelection();
    }
    public void updateImage(TableView<Slide> slidesTabelView, TextField fileName
            , TextField captionTextFiel, Slider currentHeightSlider, Slider currentWidthSlider){
        Slide slide= slidesTabelView.getSelectionModel().getSelectedItem();
        if(slide == null)
            return;
        slide.setCaption(captionTextFiel.getText());
        
        slide.setCurrentHeight((int)currentHeightSlider.getValue());
        slide.setCurrentWidth((int)currentWidthSlider.getValue());
        //slidesTabelView.getSelectionModel().clearSelection();
        app.getGUI().updateToolbarControls(false);
    }
    // THIS HELPER METHOD LOADS AN IMAGE SO WE CAN SEE IT'S SIZE
    private Image loadImage(String imagePath) throws MalformedURLException {
	File file = new File(imagePath);
	URL fileURL = file.toURI().toURL();
	Image image = new Image(fileURL.toExternalForm());
	return image;
    }
}