package sc.workspace;

import djf.ui.AppMessageDialogSingleton;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import javafx.collections.ObservableList;
import javafx.scene.control.Button;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.Slider;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import properties_manager.PropertiesManager;
import sc.SlideshowCreatorApp;
import static sc.SlideshowCreatorProp.APP_PATH_WORK;
import static sc.SlideshowCreatorProp.FILENAME_NULL_MESSAGE;
import static sc.SlideshowCreatorProp.FILENAME_NULL_TITLE;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_MESSAGE;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_TITLE;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;

/**
 * This class provides responses to all workspace interactions, meaning
 * interactions with the application controls not including the file
 * toolbar.
 * 
 * @author Richard McKenna
 * @version 1.0
 */
public class SlideshowCreatorController {
    // THE APP PROVIDES ACCESS TO OTHER COMPONENTS AS NEEDED
    SlideshowCreatorApp app;

    /**
     * Constructor, note that the app must already be constructed.
     */
    public SlideshowCreatorController(SlideshowCreatorApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
    }
    
    // CONTROLLER METHOD THAT HANDLES ADDING A DIRECTORY OF IMAGES
    public void handleAddAllImagesInDirectory() throws MalformedURLException {
        try {
            // ASK THE USER TO SELECT A DIRECTORY
            DirectoryChooser dirChooser = new DirectoryChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            dirChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            File dir = dirChooser.showDialog(app.getGUI().getWindow());
            SlideshowCreatorWorkspace work = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
            TableView ImageTable = work.getImageTable();

            if (dir != null) {
                File[] files = dir.listFiles();
                for (File f : files) {
                    String fileName = f.getName();
                    if (fileName.toLowerCase().endsWith(".png") ||
                            fileName.toLowerCase().endsWith(".jpg") ||
                            fileName.toLowerCase().endsWith(".gif")) {
                        String path = f.getPath();
                        String caption = "";
                        Image slideShowImage = loadImage(path);
                        int originalWidth = (int)slideShowImage.getWidth();
                        int originalHeight = (int)slideShowImage.getHeight();
                        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                        Slide s = new Slide(fileName, path, caption, originalWidth, originalHeight);
                        if(data.containsSlide(fileName, path)) {
                        clearTextFields();
                        ImageTable.getSelectionModel().clearSelection();
                        System.out.println("Slide " + s.getFileName() + " already added"); }

                        else{ data.addSlide(fileName, path, caption, originalWidth, originalHeight);
                              clearTextFields();
                              ImageTable.getSelectionModel().clearSelection();
                              app.getGUI().getFileController().markAsEdited(app.getGUI());
                        } 
                    }
                }
            } 
        }
        catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }
    
    public void handleAddSingleImage(){
        try{
            SlideshowCreatorWorkspace work = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
            Button removeButton = work.getRemoveButton();
            FileChooser dirChooser = new FileChooser();
            TableView ImageTable = work.getImageTable();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            dirChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            File dir = dirChooser.showOpenDialog(app.getGUI().getWindow());
            if( dir != null){
                File file = dir.getAbsoluteFile();
                String fileName = file.getName();
                String path = file.getPath();
                String caption = " ";
                Image slideShowImage = loadImage(path);
                int originalWidth = (int)slideShowImage.getWidth();
                int originalHeight = (int)slideShowImage.getHeight();
                SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                Slide s = new Slide(fileName,path,caption,originalWidth,originalHeight);
                if(data.containsSlide(fileName, path)) {
                System.out.println("Slide " + s.getFileName() + " already added");
                 }

                else{ data.addSlide(fileName, path, caption, originalWidth, originalHeight); 
                
                ImageTable.requestFocus();
                ImageTable.getSelectionModel().select(s);
               for(int i = 0; i <ImageTable.getItems().size(); i++){
                    Slide sl = (Slide) ImageTable.getItems().get(i);
                    if(sl.compareTo(s) == 0) {
                        ImageTable.getSelectionModel().select(i);
                        ImageTable.getSelectionModel().focus(i);
                    }
                }
               app.getGUI().getFileController().markAsEdited(app.getGUI());
               removeButton.setDisable(false);

                
                }
            }
        }
        catch(MalformedURLException murle){
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
        
    }
    
    public void handleRemoveSlide(){
        SlideshowCreatorWorkspace work = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
        SlideshowCreatorData data = (SlideshowCreatorData) app.getDataComponent();
        TableView ImageTable = work.getImageTable();
        Object selectedItem = ImageTable.getSelectionModel().getSelectedItem();
        try{
        Slide slide = (Slide) selectedItem;
        String fileName = slide.getFileName();
        String path = slide.getPath();
        String caption = slide.getCaption();
        int OrigWidth = slide.getOriginalWidth();
        int OrigHeight = slide.getOriginalHeight();
        ObservableList<Slide> tableData = data.getSlides();
        tableData.remove(slide);
        ImageTable.getSelectionModel().clearSelection();
        clearTextFields();
        app.getGUI().getFileController().markAsEdited(app.getGUI());
        
        }
        catch(NullPointerException e){
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
	    dialog.show(props.getProperty(FILENAME_NULL_TITLE), props.getProperty(FILENAME_NULL_MESSAGE));
        }
        
        
    }
    public void clearTextFields(){
        SlideshowCreatorWorkspace work = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
        TableView ImageTable = work.getImageTable();
        TextField FileNameText = work.getFileNameTextField();
        TextField PathText = work.getPathTextField();
        TextField CaptionText = work.getCaptionTextField();
        TextField OrigWidthText = work.getOrigWidthTextField();
        TextField OrigHeightText = work.getOrigHeightTextField();
        Slider CurrWidthSlider = work.getWidthSlider();
        Slider CurrHeightSlider = work.getHeightSlider();
        
        FileNameText.clear();
        PathText.clear();
        CaptionText.clear();
        OrigWidthText.clear();
        OrigHeightText.clear();
        CurrWidthSlider.setValue(0);
        CurrHeightSlider.setValue(0);
    }
    public void handleSelectImage(){
        SlideshowCreatorWorkspace work = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
        TableView ImageTable = work.getImageTable();
        TextField FileNameText = work.getFileNameTextField();
        TextField PathText = work.getPathTextField();
        TextField CaptionText = work.getCaptionTextField();
        TextField OrigWidthText = work.getOrigWidthTextField();
        TextField OrigHeightText = work.getOrigHeightTextField();
        Slider CurrentWidthSlider = work.getWidthSlider();
        Slider CurrentHeightSlider = work.getHeightSlider();
        
        
        Object selectedItem = ImageTable.getSelectionModel().getSelectedItem();
        
        if(!(selectedItem == null)){
            Slide s = (Slide)selectedItem;
            
            String fileName = s.getFileName();
            String path = s.getPath();
            String caption = s.getCaption();
            int origWidth = s.getOriginalWidth();
            int origHeight = s.getOriginalHeight();
            int width = s.getCurrentWidth();
            int height = s.getCurrentHeight();
            
            FileNameText.setText(fileName);
            PathText.setText(path);
            CaptionText.setText(caption);
            OrigWidthText.setText(String.valueOf(origWidth));
            OrigHeightText.setText(String.valueOf(origHeight));
            CurrentWidthSlider.setValue(width);
            CurrentHeightSlider.setValue(height);
            
            
            
                        
        }
        else System.out.println("Nothing Selected");
    }
    
    
    public void handleUpdateSlide(){
        SlideshowCreatorWorkspace work = (SlideshowCreatorWorkspace) app.getWorkspaceComponent();
        SlideshowCreatorData data = (SlideshowCreatorData) app.getDataComponent();
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        TableView ImageTable = work.getImageTable();
        Object selectedItem = ImageTable.getSelectionModel().getSelectedItem();
        ObservableList<Slide> tableData = data.getSlides();
        int selindex = tableData.indexOf(selectedItem);
        try{
            Slide slide = (Slide) selectedItem;
            String caption = slide.getCaption();
            int currW = slide.getCurrentWidth();
            int currH = slide.getCurrentHeight();
     
        TextField CaptionText = work.getCaptionTextField();
        Slider currentWidth = work.getWidthSlider();
        Slider currentHeight = work.getHeightSlider();
        
        String Caption = CaptionText.getText();
        int cW = (int) currentWidth.getValue();
        int cH = (int) currentHeight.getValue();
        
        slide.setCaption(Caption);
        slide.setCurrentWidth(cW);
        slide.setCurrentHeight(cH);
        tableData.set(selindex, slide);
        clearTextFields();
        app.getGUI().getFileController().markAsEdited(app.getGUI());
        ImageTable.getSelectionModel().clearSelection();
        }
        catch(NullPointerException e){ }
    }
    // THIS HELPER METHOD LOADS AN IMAGE SO WE CAN SEE IT'S SIZE
    private Image loadImage(String imagePath) throws MalformedURLException {
	File file = new File(imagePath);
	URL fileURL = file.toURI().toURL();
	Image image = new Image(fileURL.toExternalForm());
	return image;
    }
}